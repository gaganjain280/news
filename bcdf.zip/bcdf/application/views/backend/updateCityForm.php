<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>
<style>
	.file_button_container,
	.file_button_container input {
		height: 47px;
		width: 263px;
	}

	.file_button_container_img {
		background: transparent url(http://i.stack.imgur.com/BT5AB.png) left top no-repeat;
	}

	.file_button_container input {
		opacity: 0;
	}

</style>
<style>
.add-news-form input{
	border: 1.5px solid #45243C;
}
.add-news-form textarea{
	border: 1.5px solid #45243C;
}
.add-news-form select{
	border: 1.5px solid #45243C;
	
}
.input-group-append{
	border: 1.5px solid #45243C;
}
</style>
<!-- Main content -->
<section class="content">

	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<!-- Default box -->
				<div class="card card-primary">
					<div class="card-header">
						<h3 class="card-title col-4"><?php echo $listType;?></h3>

					</div>
					<div id="msg-div">
						<?php echo $this->session->flashdata('result'); ?>
					</div>
					<div>
						<div>
							<div class="card-body login-card-body">
<!-- Array ( [0] => stdClass Object ( [id] => 9 [kshetra_id] => 11 [nagar] => world [nagar_sort_code] => www [created_by] => AST-1 [created_at] => 2020-06-24 04:01:10 [updated_at] => 2020-06-24 07:31:10 [name] => world commite ) ) -->
								<form action="<?php echo base_url();?>city/updateQuery/<?php echo $id;?>" method="post"
									enctype="multipart/form-data" class="add-news-form">
									<div class="row">
										<div class="col-md-6">
											<label for="Kshetra">Kshetra(क्षेत्र का चयन करें)</label>
											<div class="input-group mb-3">
                                           <select class="form-control" name="kshetras" style="border-right: 2px solid;" id="select1" required>
                                              <?php 
									      for($i=0;$i<sizeof($kshetraList);$i++){
        								if($kshetraList[$i]->id==$cityData[0]->kshetra_id){
							               echo '<option value='.$kshetraList[$i]->id.' selected>'.$kshetraList[$i]->kshetra_name.'</option>';
				        					}else{
									       echo'<option value='.$kshetraList[$i]->id.'>'.$kshetraList[$i]->kshetra_name.'</option>';				        						
				        					}					
										      } ?>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Source">City Code(शहर का कोड)</label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="code" name="code"
													placeholder="Please type city code here" value="<?php echo $cityData[0]->nagar_sort_code;?>" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-external-link-alt"></span>
													</div>
												</div>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<label for="Description">City Committee Name(नगर समिति का नाम)</label>
											<div class="input-group mb-3">
                                      <input type="text" class="form-control" id="CommitteeName" name="CommitteeName"
													placeholder="Please type city CommitteeName here" value="<?php echo $cityData[0]->name;?>" required />
										<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-newspaper"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Heading">City Name(शहर का नाम)</label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="name" name="name"
													placeholder="Please type city name here" value="<?php echo $cityData[0]->nagar;?>" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-newspaper"></span>
													</div>
												</div>
											</div>
										</div>
										
									</div>
									<div class="row">
											<div class="form-group col-lg-12 col-md-12 col-xs-12">
												<div id="news-image" class="p-2"
													style="border:1px solid #73B3FE; display:none">
												</div>
											</div>
										</div>
									<hr>
									<div class="row">
										<div class="col-2">
											<button type="submit" class="btn btn-success btn-block">Add Nagar</button>
										</div>
										<!-- /.col -->
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /.card -->
			</div>
		</div>
	</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
<script>
	$(function () {
		$(":file").change(function () {
			if (this.files && this.files[0]) {
				for (var i = 0; i < this.files.length; i++) {

					var reader = new FileReader();
					reader.fileName = this.files[i].name;
					reader.onload = imageIsLoaded;
					reader.readAsDataURL(this.files[i]);
					//var fileName=this.files[i].name;// to get filename for uploaded files

				}
			}
		});
	});

	function imageIsLoaded(e) {
		// alert(e.target.fileName);
		document.getElementById('news-image').style.display = 'block';
		var imgSrc = '';
		imgSrc += '&nbsp;<img src=' + e.target.result + ' height="150" width="150" >';
		imgSrc += '';

		$('#news-image').append(imgSrc);
	};

</script>
<script>
	$(document).ready(function(){
		
		setTimeout(function () {
			$('#msg-div').hide();
		}, 3000);
	});

	</script>