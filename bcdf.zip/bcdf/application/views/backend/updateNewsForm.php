<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>
<style>
.update-news-form input{
	border: 1.5px solid #45243C;
}
.update-news-form textarea{
	border: 1.5px solid #45243C;
}
.update-news-form select{
	border: 1.5px solid #45243C;
	
}
.input-group-append{
	border: 1.5px solid #45243C;
}
</style>
<!-- Main content -->
<section class="content">

	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<!-- Default box -->
				<div class="card card-primary">
					<div class="card-header card-warning">
						<h3 class="card-title col-4"><?php echo $listType;?></h3>
						
					</div>
					<div id="msg-div">
						<?php echo $this->session->flashdata('result'); ?>
					</div>
					<div>
						<div>
							<div class="card-body login-card-body">
						<form class="update-news-form" action="<?php echo base_url();?>/news/update/<?php echo $id;?>"
									method="post" enctype="multipart/form-data">

									<div class="row">
										<div class="col-md-6">
										<label for="Heading">Title/Heading</label>
									<div class="input-group mb-3">
										<input type="context" class="form-control"
											value="<?php echo $updateData[0]->context;?>" id="context" name="context"
											placeholder="Please type context here" required />
										<div class="input-group-append">
											<div class="input-group-text">
												<span class="fas fa-newspaper"></span>
											</div>
										</div>
									</div>
										</div>
										<div class="col-md-6">
										<label for="Source">News Source</label>
									<div class="input-group mb-3">
										<input type="context" class="form-control"
											value="<?php echo $updateData[0]->source;?>" id="source" name="source"
											placeholder="Please type source of information here" required />
										<div class="input-group-append">
											<div class="input-group-text">
												<span class="fas fa-external-link-alt"></span>
											</div>
										</div>
									</div>
										</div>
									</div>
									
									<label for="Description">Description</label>
									<div class="input-group mb-3">
										<textarea type="text" id="description" value="" name="description"
											class="form-control" placeholder="Please type description here"
											required><?php echo $updateData[0]->description;?></textarea>
										<div class="input-group-append">
											<div class="input-group-text">
												<span class="fas fa-scroll"></span>
											</div>
										</div>
									</div>
									
										<div class="col-md-6">
											<label for="Description">Visible to</label>
											<div class="input-group mb-3">
								<select class="form-control" name="visible[]" multiple="multiple" style="border-right: 2px solid;" id="select1"  required>
									<?php 
									$insertedKshetra=json_decode($updateData[0]->kshetra);
									for($j=0;$j<sizeof($kshetraList);$j++){
										if (in_array($kshetraList[$j]->id, $insertedKshetra)) {
                                        // echo '<option value=1 selected> hiiiii</option>';
                               echo'<option value='.(string)$kshetraList[$j]->id.' selected >'.(string)$kshetraList[$j]->kshetra_name.'</option>';
										}else{
                               echo'<option value='.(string)$kshetraList[$j]->id.'>'.(string)$kshetraList[$j]->kshetra_name.'</option>';

										}
									}?>
										
										</select>
											</div>
										</div>
									
									<img width="300" height="200"
										src="<?php echo base_url('assets/images/news/'.$updateData[0]->image_name);?>" />
									<div class="input-group mb-3 md-3">
										<input class="form-control" type="file" name="image" />
										<div class="input-group-append">
											<div class="input-group-text">
												<span class="fas fa-image"></span>
											</div>
										</div>
									</div><hr>
									<div class="row">
									<div class="col-10">
                                  <div class="icheck-primary">
								 <?php if($updateData[0]->status==1){
								     echo'<input type="checkbox" name ="apply" id="apply" checked>';
								 }else{
								     echo'<input type="checkbox" name ="apply" id="apply">';
								    }?>
										<label for="apply">
											Show on Website / Active
										</label>
									</div>
										</div>
										<div class="col-2">
												<button type="submit" class="btn btn-primary btn-block">Update
													</button>
										</div>
								</form>
							</div>
							<!-- /.login-card-body -->
						</div>
					</div>
				</div>
				<!-- /.card -->
			</div>
		</div>
	</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->


<?php include "layouts/footer.php"?>
<script>
	$(document).ready(function(){
		
		setTimeout(function () {
			$('#msg-div').hide();
		}, 3000);
	});

	</script>