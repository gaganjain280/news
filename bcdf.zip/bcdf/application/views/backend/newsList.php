<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>
<style>
	.news-pagination>.page-item>a {

		position: relative;
		display: block;
		padding: .5rem .75rem;
		margin-left: -1px;
		line-height: 1.25;
		color: #007bff;
		background-color: #fff;
		border: 1px solid #dee2e6;
		padding: .25rem .5rem;
	}

	.news-pagination>.page-item>strong {

		position: relative;
		display: block;
		padding: .5rem .75rem;
		margin-left: -1px;
		line-height: 1.25;
		color: #007bff;
		background-color: #fff;
		border: 1px solid #dee2e6;
		padding: .25rem .5rem;
	}

</style>

<!-- Main content -->
<section class="content">

	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<!-- Default box -->
				<div class="card" style="border:1px solid #343A40">
					<div class="card-header">
						<h3 class="card-title" style="padding:10px;"><?php echo $listType;?></h3>
						<h3 class="float-right"><a href="<?php echo base_url();?>news/addNews"
								class="btn btn-outline-primary btn-sm">Add News</a>
						</h3>
					</div>
					<!-- /.card-header -->
					<div>
						<div class="table-responsive">
							<table class="table table-bordered table-striped m-0">
								<thead style="background-color:#343A40;color:#fff;text-align:center">
									<tr>
										<th>S.No</th>
										<th>Headlines</th>
										<th>Description </th>
										<th>Creator Asati Id</th>
										<th>Created Date</th>
										<th>Status</th>
										<th class="center">Action</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach($newsData as $row): ?>
									<tr>
										<td style="text-align:center"><?php echo $row->id; ?></td>
										<td><?php echo $row->context; ?></td>
										<td><?php echo $row->description; ?></td>
										<td style="text-align:center"><?php echo $row->creator_id; ?></td>
										<td style="text-align:center"><?php echo $row->created_at; ?></td>
										<td style="text-align:center"><?php if($row->status==1){
                                         echo'Active';
										}
										else{
											echo'Not Active';
										}?>
										</td>
										<td style="text-align:center"><a
												href="<?php echo base_url();?>news/updateNewsForm/<?php echo $row->id;?>"
												class="btn btn-outline-info btn-sm"><i
													class="fas fa-edit nav-icon"></i></a>
											<a href="<?php echo base_url();?>news/delete/<?php echo $row->id;?>"
												class="btn btn-outline-danger btn-sm"><i
													class="fas fa-trash nav-icon"></i></a>
										</td>
									</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
					<!-- /.card-body -->
					<div class="card-footer clearfix" style="">
						<ul class="pagination pagination-sm m-0 float-right news-pagination">
							<!-- <li class="page-item"><a class="page-link" href="0">&laquo;</a></li> -->
							<li class="page-item" style="display:contents">
								<?php echo $this->pagination->create_links(); ?></li>
						</ul>
					</div>
				</div>

				<!-- /.card -->
			</div>
		</div>
	</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
