<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?php echo $listType;?></h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
                </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered">
                    <thead>                  
                      <tr>
                        <th>S.No</th>
                        <th>Family Name </th>
                        <th>Family ID </th>
                        <th>Family Head </th>
                        <th>Mobile Number </th>
                        <th>No of Members </th>
                        <th>Kshetra City  </th>
                        <th>Family Head </th>
                        <th>Created </th>
                        <th>View Family </th>
                        <th>Family Status</th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td>demo1  </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr>
                    </tbody>
                </table>
              </div>
              <!-- /.card-body -->
               <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right">
                  <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                </ul>
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
