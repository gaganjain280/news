<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>

<style>
  .news-pagination>.page-item>a {

    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #007bff;
    background-color: #fff;
    border: 1px solid #dee2e6;
    padding: .25rem .5rem;
  }

  .news-pagination>.page-item>strong {

    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #007bff;
    background-color: #fff;
    border: 1px solid #dee2e6;
    padding: .25rem .5rem;
  }

</style>

<section class="content">

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card" style="border:1px solid #343A40">
          <div class="card-header">
            <h3 class="card-title" style="padding:10px;"><?php echo $listType;?></h3>
            <input type="hidden" id="kshetra_id" value="<?php echo $kshetra_id;?>"/>
            <h3 class="float-right"><a href="<?php echo base_url();?>city/addCity"
                class="btn btn-outline-primary btn-sm">Add Nagar</a>
            </h3>
          </div>
          <!-- /.card-header -->
           <div class="container">
                    <div class="row">
                        <div class="col-12">
                          <table id="table_id" class="display">
                              <thead>
                                  <tr>
                                      <th>S.No</th>
                                      <th>City </th>
                                      <th>City Code </th>
                                      <th>Kshetra Id </th>
                                      <th>Action </th>
                                  </tr>
                              </thead>
                              <tbody>
                              </tbody>
                          </table>        
                          </div>
                      </div>
              </div>
          <div class="card-footer clearfix" style="">

          </div>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
</div>
<!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
 <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js" type="text/javascript"></script>
<script>
   $(document).ready(function(){
      var base_url = "<?php echo base_url();?>"; // You can use full url here but I prefer like this
      var kshetra_id=$('#kshetra_id').val();
      var dataString = "kshetra_id="+kshetra_id;
       tHtml="";
        $.ajax({
            type: "POST",
            url: base_url+'CommitteeController/getcityAsti',
            data: dataString,
            crossDomain: true,
            cache: false,
            // dataType: 'JSON',
            success: function (result) {
              var getObject = JSON.parse(result);
                $.each(getObject, function (i, item) {
                   var nagar_id = item['id'];
                    var nagar = item['nagar'];
                    var nagar_sort_code = item['nagar_sort_code'];
                    var kshetra_id = item['kshetra_id'];
                    tHtml += "<tr><td >" + nagar_id+ "</td><td  style='font-weight:600'>" + nagar+ "</td><td class='text-uppercase' style='font-weight:600'>" + nagar_sort_code + "</td><td class='text-uppercase' style='font-weight:600'>" + kshetra_id + "</td><td class='text-uppercase' style='font-weight:600'><a class='btn btn-primary btn-sm' href='<?php echo base_url();?>city/updateCityForm/"+nagar_id+"'>Update</a></td>";
                        tHtml += "</tr>";
                });

                $('#table_id tbody').html(tHtml);
            }
        }); //end ajax

 $('#table_id').DataTable();
  
   });


</script>

