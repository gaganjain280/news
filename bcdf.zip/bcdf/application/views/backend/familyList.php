<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?php echo $listType;?></h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
                </div>
              </div>
              <div class="card-body">
                <!-- <?php print_r($family)?> -->
                <table class="table table-bordered">
                    <thead>                  
                      <tr>
                        <th>S.No</th>
                        <th>Family Name </th>
                        <th>Family ID </th>
                        <th>Family Head </th>
                        <th>Mobile Number </th>
                        <th>No of Members </th>
                        <th>Kshetra   </th>
                        <th>City  </th>
                        <th>Created </th>
                        <th>View Family </th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>

  
                      <?php 
                      if(count($family)):
                      // print_r($family);

                      $count = $this->uri->segment(4, 0);
                      foreach($family as $fam ): ?>
                        <tr>
                          <td><?=$fam->id?>  </td>
                          <td><?=$fam->f_name?></td>
                          <td><?=$fam->f_asati_id?></td>
                          <td><?=$fam->id?></td>
                          <td><?=$fam->id?></td>
                          <td>0 </td>
                          <td><?=$fam->kshetra_name?></td>
                          <td><?=$fam->nagar?></td>
                          <td><?=$fam->created?></td>
                          <td> <a href="<?=base_url()?>family/view/<?=$fam->id?>" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> 
                    <?php endforeach; ?>
                    <?php else: ?>
                      
                    <?php endif; ?>
  


                <!--         <tr>
                          <td>1  </td>
                          <td>01 झाँसी अनूप कैलाश असाटी, गिदवाहवाले  </td>
                          <td>FAMILY-JBP-000850  </td>
                          <td>Ranu  </td>
                          <td>7894561235 </td>
                          <td>5  </td>
                          <td>Bhopal  </td>
                          <td>Bhopal  </td>
                          <td>  18/1/2020, 8:48:10 pm  </td>
                          <td> <a href="<?=base_url()?>family/view/1" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> <tr>
                          <td>2 </td>
                          <td>01, कुम्हेडी गोपाल दास पंचमलाल असाटी </td>
                          <td>FAMILY-JBP-0008510  </td>
                          <td>Ravindra  </td>
                          <td>7894561288 </td>
                          <td>6  </td>
                          <td>raisen  </td>
                          <td>Bareli  </td>
                          <td>  19/1/2020, 8:48:10 pm  </td>
                          <td> <a href="<?=base_url()?>family/view/1" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> <tr>
                          <td>3 </td>
                          <td>Jain parivar   </td>
                          <td>FAMILY-JBP-000851  </td>
                          <td>Rupali  </td>
                          <td>7898521235 </td>
                          <td>1  </td>
                          <td>indore  </td>
                          <td>indore  </td>
                          <td>  18/1/2020, 8:48:10 pm  </td>
                          <td> <a href="<?=base_url()?>family/view/1" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> <tr>
                          <td>4  </td>
                          <td>Asati parivar </td>
                          <td>FAMILY-JBP-000887  </td>
                          <td>Rashan  </td>
                          <td>7894561235 </td>
                          <td>5  </td>
                          <td>USA  </td>
                          <td>NA  </td>
                          <td>  24/1/2020, 7:48:10 pm  </td>
                          <td> <a href="<?=base_url()?>family/view/1" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> -->
                    </tbody>
                </table>
              </div>
              <!-- /.card-body -->
               <div class="card-footer clearfix">
            <!--     <ul class="pagination pagination-sm m-0 float-right">
                  <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                </ul> -->
                <?php echo $this->pagination->create_links(); ?>

              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
