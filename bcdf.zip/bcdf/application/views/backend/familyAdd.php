<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>


<style>
	.callout-primary {

		border-left-color: #FF9800;
	}

</style>
<style>
	.add-family-form-t input {
		/* border: 0 none; */
		border: 1.5px solid #45243C;
	}

	.add-family-form-t select {
		/* border: 0 none; */
		border: 1.5px solid #45243C;
	}

</style>
<!-- Main content -->
<section class="content">

	<!-- Default box -->
	<div class="card card-solid">
		<div>
			    <?php if( $feedback = $this->session->flashdata('feedback')){ 
            $feedback_class = $this->session->flashdata('feedback_class');
          ?>
           <div class="alert alert-dismissible <?= $feedback_class ?>">
              <?= $feedback ?>
            </div>
          <?php } ?>
			<div class="row">
				<div class="col-12 col-sm-12 col-md-12">
					<div class="card card-primary">
						<div class="card-header" style="background-color: #FF9800">
							<h3 class="card-title">Add New Family / नया परिवार जोड़ें</h3>
						</div>
						<form class="add-family-form-t" role="form" method="Post"
							action="<?php echo base_url();?>/family/add" enctype="multipart/form-data">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12">
										<div class="callout callout-primary p-2">
											<span class="badge p-2"
												style="background-color: #FF9800;color:#fff">1</span>&nbsp;<b>Family
												Photo / परिवार की तस्वीर</b>
										</div>
									</div><br>
									<div class="col-md-6">
										<div class="form-group">
											<label for="">Family Photo / परिवार की तस्वीर</label>
											<input style="border:none" type="file" class="" name="familyImg"
												id="familyImg" required>
										</div>
									</div>
									<div class="col-md-6">
										<div id="fam-photo" class="p-2"
											style="display:none">
										</div>
									</div>
									<!-- <div class="col-md-6">
										<div class="form-group">
											<label for="">Head Member Photo / परिवार के मुखिया की तस्वीर</label>
											<input style="border:none" type="file" class="" name="memberImg" id="memberImg" required>
										</div>
									</div> -->
								</div>
								<br>
								<div class="row">
									<div class="col-12">
										<div class="callout callout-primary p-2">
											<span class="badge p-2"
												style="background-color: #FF9800;color:#fff">2</span>&nbsp;<b>Family
												Head Details / परिवार के मुखिया का विवरण</b>
										</div>
									</div>
								</div>

								<div class="row">

									<div class="col-md-2">
										<div class="form-group">
											<label for="">Salutation / अभिवादन *</label>
											<select class="form-control" name="salutation" id="salutation" required>
												<option disabled selected="selected">Select</option>
												<option value="Shri"> Shri </option>
												<option value="Smt"> Smt </option>
												<option value="Kumari"> Kumari </option>
												<option value="CA"> CA </option>
												<option value="Dr"> Dr </option>
												<option value="Er"> Er </option>
												<option value="Gen"> Gen </option>
												<option value="Justice"> Justice </option>
												<option value="Other"> Other </option>
											</select>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">First Name / प्रथम नाम *</label>
											<input type="text" class="form-control" name="firstName" id="firstName"
												placeholder="First Name" required>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">Middle Name / मध्य नाम *</label>
											<input type="text" class="form-control" name="middleName" id="middleName"
												placeholder="Middle Name">
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<label for="">Last Name / सरनेम *</label>
											<select class="form-control" name="lastName" id="lastName" required>
												<option disabled selected="selected">Last Name</option>
												<option value="Asati"> Asati </option>
												<option value="Modi"> Modi </option>
												<option value="Sahu"> Sahu </option>
											</select>
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<label for="">Suffix / उपनाम *</label>
											<select class="form-control" name="lastName" id="lastName" required>
												<option disabled selected="selected">Suffix</option>
												<option value="Asati"> Asati </option>
												<option value="Modi"> Modi </option>
												<option value="Sahu"> Sahu </option>
											</select>
										</div>
									</div>

								</div>
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label for="">Indigenous People / मूल निवासी *</label>
											<input type="text" name="indigenous" class="form-control" id="indigenous"
												placeholder="Indigenous">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="">Gotra / गोत्र *</label>
											<input type="text" name="gotra" class="form-control" id="gotra"
												placeholder="Gotra">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="">Dynasty / वंश *</label>
											<input type="text" name="dynasty" class="form-control" id="dynasty"
												placeholder="Dynasty">
										</div>
									</div>
								</div>
								
								<br>
								<div class="row">
									<div class="col-12">
										<div class="callout callout-primary p-2">
											<span class="badge p-2"
												style="background-color: #FF9800;color:#fff">3</span>&nbsp;<b>Contact Details / संपर्क विवरण</b>
										</div>
									</div>
								</div>
								<br>
								<div class="row">

											<div class="col-md-2">
												<div class="form-group">
													<label for="">ISD *</label>
													<select class="form-control" name="isd" id="isd">
														<option>91</option>
													</select>
												</div>
											</div>
											<div class="col-md-5">
												<div class="form-group">
													<label for="">Mobile / मोबाइल *</label>
													<input type="text" name="mobile" class="form-control" id="mobile"
														placeholder="Mobile">
												</div>
											</div>
											<div class="col-md-5">
												<div class="form-group">
													<label for="">Email / ईमेल *</label>
													<input type="email" name="email" class="form-control" id="email"
														placeholder="Email">
												</div>
											</div>
										</div>
								<br>
								<div class="row">
									<div class="col-md-12">
										<div class="callout callout-primary p-2">
											<span class="badge p-2"
												style="background-color: #FF9800;color:#fff">4</span>&nbsp;<b>Family
												Address / परिवार का पता</b>
										</div>
									</div>
								</div><br>

								<div class="row">
									<div class="col-md-3">
										<div class="form-group">
											<label for="">House No / मकान नंबर</label>
											<input type="text" name="house_no" class="form-control" id="house_no"
												placeholder="House No">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">House Name / घर का नाम </label>
											<input type="text" name="house_name" class="form-control" id="house_name"
												placeholder="House Name ">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">Colony / Village (कालोनी / गाँव) </label>
											<input type="text" name="colony" class="form-control" id="colony"
												placeholder="Colony">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">Pin Code / पिन कोड</label>
											
                           <div class="autocomplete">
                          <!-- <input id="myInput" type="text" name="myCountry" placeholder="Country"> -->
                          <input type="text" name="pincode" class="form-control" id="pincode"
                        placeholder="Pin Code">
                          <div id="pincodeautocomplete-list" class="autocomplete-items"></div>
                        </div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">Area /Tehsil (क्षेत्र / तहसील)</label>
											<input type="text" name="area" class="form-control" id="area"
												placeholder="Area">
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label for="">City / शहर</label>
											<input type="text" name="city" class="form-control" id="city"
												placeholder="City">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">State / राज्य</label>
											<input type="text" name="state" class="form-control" id="state"
												placeholder="State.">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label for="">Country / देश</label>
											<input type="text" name="country" class="form-control" id="country"
												placeholder="Country">
										</div>
									</div>
									
								</div>
								<br>
								<div class="row">
									<div class="col-md-6">
										<div class="row">
											<div class="col-md-12">
												<div class="callout callout-primary p-2">
													<span class="badge p-2"
														style="background-color: #FF9800;color:#fff">5</span>&nbsp;<b>Present
														Samiti / वर्तमान समिति</b>
												</div>
											</div>
										</div>
										<br>
										<div class="row">

											<div class="col-md-6">
												<div class="form-group">
													<label for="">Select Kshetra / क्षेत्र का चयन
														करें *</label>
													<select class="form-control" name="kshetra" id="kshetra">
														<option disabled selected="selected">Select Kshetra</option>
														<?php
                                                  $kshetra = $this->db->get('kshetra')->result_array();
                                                    foreach($kshetra as $row):
                                                  ?>
														<option value="<?php echo $row['id'];?>">
															<?php echo $row['kshetra_name'];?></option>
														<?php
                                                    endforeach;
                                                    ?>
													</select>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label for="">Select Nagar Samiti / नगर समिति
														चुने</label>
													<select class="form-control" name="nagar" id="nagar">
														<option value="1">option 1</option>
														<option>option 2</option>
														<option>option 3</option>
														<option>option 4</option>
														<option>option 5</option>
													</select>
												</div>
											</div>
										</div>

									</div>
									<div class="col-md-6">
										<div class="row">
											<div class="col-md-12">
												<div class="callout callout-primary p-2">
													<span class="badge p-2"
														style="background-color: #FF9800;color:#fff">6</span>&nbsp;<b>Password / पासवर्ड</b>
												</div>
											</div>
										</div>
										<br>
										<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="">Password / पासवर्ड *</label>
											<input type="password" class="form-control" name="password" id="password"
												placeholder="Create Password" required>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="">Confirm Password / अनुरूप पासवर्ड *</label>
											<input type="password" class="form-control" name="password" id="password"
												placeholder="Create Password" required>
										</div>
									</div>
								</div>

									</div>
								</div><br>



								

								<div class="row">
									<div class="col-6"></div>
									<div class="col-6"></div>
								</div>

							</div>
							<!-- /.card-body -->

							<div class="card-footer">
								<button type="submit" class="btn btn-primary float-right">Submit</button>
							</div>
						</form>
					</div>
				</div>

			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-footer">
			<nav aria-label="Contacts Page Navigation">
			</nav>
		</div>
		<!-- /.card-footer -->
	</div>
	<!-- /.card -->

</section>
<!-- /.content -->
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
<script>
	$(function () {
		$(":file").change(function () {
			if (this.files && this.files[0]) {
				for (var i = 0; i < this.files.length; i++) {

					var reader = new FileReader();
					reader.fileName = this.files[i].name;
					reader.onload = imageIsLoaded;
					reader.readAsDataURL(this.files[i]);
					//var fileName=this.files[i].name;// to get filename for uploaded files

				}
			}
		});
	});

	function imageIsLoaded(e) {
		// alert(e.target.fileName);
		document.getElementById('fam-photo').style.display = 'block';
		document.getElementById('fam-photo').innerHTML = '';
		var imgSrc = '';
		imgSrc += '&nbsp;<img class="float-right" src=' + e.target.result + ' height="150" width="150" >';
		imgSrc += '';

		$('#fam-photo').append(imgSrc);
	};

</script>
<style>
	label:not(.form-check-label):not(.custom-file-label) {
		font-weight: 400 !important;
	}

	.form-control {
		border-radius: 0;
		height: calc(2.25rem + -2px);
	}

</style>

<script>
	$(document).ready(function () {
		$("#kshetra").change(function () {
			var id = this.value;

			$.ajax({
				url: "<?php echo site_url('family/nagarbyid');?>",
				method: "POST",
				data: {
					id: id
				},
				async: true,
				dataType: 'json',
				success: function (data) {
					var html = '';
					var i;
					html += '<option disabled  selected="selected"> Select Nagar</option>';
					for (i = 0; i < data.length; i++) {
						html += '<option value=' + data[i].id + '>' + data[i].nagar +
							'</option>';
					}
					$('#nagar').html(html);
				}
			});
			return false;
		});


    $("#pincode").keyup(function () {
      var str = this.value;
      if (str !== "") {
          $.ajax({
            url: "<?php echo site_url('pincode');?>",
            method: "POST",
            data: {
              str: str
            },
            async: true,
            dataType: 'json',
            success: function (data) {
              console.log(data);
              var html = '';
              for (i = 0; i < data.length; i++) {
                html += '<div  class="pincodeAutoload" pincode="'+data[i]['pincode']+'" officename="'+data[i]['officename']+'" statename="'+data[i]['statename']+'" off="'+data[i]['off']+'" districtname="'+data[i]['districtname']+'">'+data[i]['pincode']+','+data[i]['officename']+'<input type="hidden" value="'+data[i]+'"></div>';
              }
              $('#pincodeautocomplete-list').html(html);
            }
          });

      }  
       // return false;
    });

    $('body').on('click', '.pincodeAutoload', function() {
        $('#pincode').val($(this).attr('pincode'));
        $('#area').val($(this).attr('officename'));
        $('#state').val($(this).attr('statename'));
        $('#city').val($(this).attr('districtname'));
        $('#pincodeautocomplete-list').html('');
    });
	});

</script>


<style>
  
  
#pincodeautocomplete-list{
  max-height: 300px;
  overflow-y: scroll;
}

.autocomplete-items {
  position: absolute;
  border: 1px solid #d4d4d4;
  border-bottom: none;
  border-top: none;
  z-index: 99;
  /*position the autocomplete items to be the same width as the container:*/
  /*top: 100%;*/
  left: 0;
  right: 0;
}

.autocomplete-items div {
  padding: 10px;
  cursor: pointer;
  background-color: #fff; 
  border-bottom: 1px solid #d4d4d4; 
}

/*when hovering an item:*/
.autocomplete-items div:hover {
  background-color: #e9e9e9; 
}

/*when navigating through the items using the arrow keys:*/
.autocomplete-active {
  background-color: DodgerBlue !important; 
  color: #ffffff; 
}
</style>