<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>
    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

              <div class="card card-primary">
                       <div class="card-header">
                         <h3 class="card-title">Add New Members</h3>
                       </div>
                          <!-- /.card-header -->
                          <!-- form start -->
                        <form role="form">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                      <b>Basic Details</b>
                                      <hr>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                            <label for="exampleInputPassword1">Title*</label>
                                            <select class="form-control">
                                                <option>option 1</option>
                                                <option>option 2</option>
                                                <option>option 3</option>
                                                <option>option 4</option>
                                                <option>option 5</option>
                                            </select>
                                        </div> 
                                    </div>
                                     <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Member Name *</label>
                                        <input type="text" class="form-control" name="FirstName" id="FirstName" placeholder="First Name">
                                      </div>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1"><br></label>
                                        <input type="text" class="form-control" name="MiddleName" id="MiddleName" placeholder="Middle Name">
                                      </div>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1"><br></label>
                                        <input type="text" class="form-control" name="LastName" id="LastName" placeholder="Last Name">
                                      </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-3">
                                      <div class="form-group">
                                            <label for="exampleInputPassword1">Title*</label>
                                            <select class="form-control">
                                                <option>option 1</option>
                                                <option>option 2</option>
                                                <option>option 3</option>
                                                <option>option 4</option>
                                                <option>option 5</option>
                                            </select>
                                        </div> 
                                    </div>
                                     <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Father's Name *</label>
                                        <input type="text" class="form-control" name="FirstName" id="FirstName" placeholder="First Name">
                                      </div>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1"><br></label>
                                        <input type="text" class="form-control" name="MiddleName" id="MiddleName" placeholder="Middle Name">
                                      </div>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1"><br></label>
                                        <input type="text" class="form-control" name="LastName" id="LastName" placeholder="Last Name">
                                      </div>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="col-3">
                                      <div class="form-group">
                                            <label for="exampleInputPassword1">Relation with Head *</label>
                                            <select class="form-control">
                                                <option>option 1</option>
                                                <option>option 2</option>
                                                <option>option 3</option>
                                                <option>option 4</option>
                                                <option>option 5</option>
                                            </select>
                                        </div> 
                                    </div>
                                     <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Gender *</label>
                                        <input type="text" class="form-control" name="FirstName" id="FirstName" placeholder="Gender *">
                                      </div>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">DOB </label>
                                        <input type="text" class="form-control" name="MiddleName" id="MiddleName" placeholder="DOB">
                                      </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Marital Status</label>
                                            <select class="form-control" id="maritalStatus" name="maritalStatus">
                                                <option disabled selected="">Select</option>
                                                <option value="married">Married</option>
                                                <option value="unmarried">Unmarried</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4" style="display: none;" id="domDiv">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Date of Marriage</label>
                                            <input type="text" name="Gotra" class="form-control" id="Gotra" placeholder="Date of Marriage">
                                        </div>
                                    </div>
                                    <div class="col-4" style="display: none;" id="iimDiv">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Interested in Matramonial</label>
                                            <select class="form-control"  id="matramonialStatus" name="matramonialStatus">
                                                  <option value="no">No</option>
                                                  <option value="yes">Yes</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Current Occupation/Job</label>
                                            <select class="form-control" name="occupation" id="occupation">
                                                <option value="">Service</option>
                                                <option value="Unemployed">Unemployed / Preparing for Jobs</option>
                                                <option value="Student">Student (School/ collage/ Prof.Studies)</option>
                                                <option value="Service">Business / Profession / Service</option>
                                                <option value="Interest">Housewife / Pension / Rent &amp; Interest</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row"  style="display: none;" id="spouseDiv">
                                    <div class="col-3">
                                      <div class="form-group">
                                            <label for="exampleInputPassword1">Title*</label>
                                            <select class="form-control">
                                                <option>option 1</option>
                                                <option>option 2</option>
                                                <option>option 3</option>
                                                <option>option 4</option>
                                                <option>option 5</option>
                                            </select>
                                        </div> 
                                    </div>
                                     <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1">Spouse's Full Name *</label>
                                        <input type="text" class="form-control" name="FirstName" id="FirstName" placeholder="First Name">
                                      </div>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1"><br></label>
                                        <input type="text" class="form-control" name="MiddleName" id="MiddleName" placeholder="Middle Name">
                                      </div>
                                    </div>
                                    <div class="col-3">
                                      <div class="form-group">
                                        <label for="exampleInputEmail1"><br></label>
                                        <input type="text" class="form-control" name="LastName" id="LastName" placeholder="Last Name">
                                      </div>
                                    </div>
                                </div>
                                <div class="row" id="martialDetailsDiv" style="display: none;">
                                    <div class="col-12">
                                      <b>Martial Details</b>
                                      <hr>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Colour Complexion</label>
                                            <select class="form-control">
                                                <option>option 1</option>
                                                <option>option 2</option>
                                                <option>option 3</option>
                                                <option>option 4</option>
                                                <option>option 5</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Mangalik Detail</label>
                                            <select class="form-control">
                                                <option>option 1</option>
                                                <option>option 2</option>
                                                <option>option 3</option>
                                                <option>option 4</option>
                                                <option>option 5</option>
                                            </select>
                                        </div>
                                    </div>
                                     <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Place of Birth</label>
                                            <input type="text" name="City" class="form-control" id="City" placeholder="City">
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Time of Birth </label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="State">
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Pitra Gotra </label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="State">
                                        </div>
                                    </div>
                                     <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Matra Gotra</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="State">
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-12">
                                      <b>Present Samaj Samiti Details</b>
                                      <hr>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Current Kshetriya Samiti</label>
                                            <input type="text" name="City" class="form-control" id="City" placeholder="City">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Current Nagar Samiti</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="State">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                  <div class="col-12">
                                      <b>Physical Details</b>
                                      <hr>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Height required</label>
                                             <select class="form-control">
                                                  <option>option 1</option>
                                                  <option>option 2</option>
                                                  <option>option 3</option>
                                                  <option>option 4</option>
                                                  <option>option 5</option>
                                              </select>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Physical Challange </label>
                                             <select class="form-control">
                                                  <option>option 1</option>
                                                  <option>option 2</option>
                                                  <option>option 3</option>
                                                  <option>option 4</option>
                                                  <option>option 5</option>
                                              </select>
                                        </div>
                                    </div>
                                     <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Blood Group </label>
                                             <select class="form-control">
                                                  <option>option 1</option>
                                                  <option>option 2</option>
                                                  <option>option 3</option>
                                                  <option>option 4</option>
                                                  <option>option 5</option>
                                              </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                  <div class="col-12">
                                      <b>Education Details</b>
                                      <hr>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Highest Education</label>
                                             <select class="form-control">
                                                  <option>option 1</option>
                                                  <option>option 2</option>
                                                  <option>option 3</option>
                                                  <option>option 4</option>
                                                  <option>option 5</option>
                                              </select>
                                        </div>
                                    </div>
                                    <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Detail of Highest Education </label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Detail of Highest Education">
                                        </div>
                                    </div>
                                     <div class="col-4">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Subject</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Subject">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                      <b>Contact Details</b>
                                      <hr>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">House No</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="House No">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">House Name </label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="House Name ">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Colony / Village </label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Colony">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Area /Tehsil</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Area">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Country</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Country">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">State</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="State.">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">City</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="City">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Pin Code</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Pin Code">
                                        </div>
                                    </div>
                                </div>

                                  <div class="row" id="shopofficeDiv" style="display: none;">
                                    <div class="col-12">
                                      <b>Shop and Office Details</b>
                                      <hr>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Present Occupation</label>
                                             <select class="form-control">
                                                  <option>option 1</option>
                                                  <option>option 2</option>
                                                  <option>option 3</option>
                                                  <option>option 4</option>
                                                  <option>option 5</option>
                                              </select>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Issncome (Per Month) </label>
                                            <select class="form-control">
                                              <option>option 1</option>
                                              <option>option 2</option>
                                              <option>option 3</option>
                                              <option>option 4</option>
                                              <option>option 5</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                          <label for="exampleInputPassword1">Type</label>
                                          <select class="form-control">
                                              <option>option 1</option>
                                              <option>option 2</option>
                                              <option>option 3</option>
                                              <option>option 4</option>
                                              <option>option 5</option>
                                          </select>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Sector / industries</label>
                                            <select class="form-control">
                                              <option>option 1</option>
                                              <option>option 2</option>
                                              <option>option 3</option>
                                              <option>option 4</option>
                                              <option>option 5</option>
                                          </select>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                      <b>Office Address </b>
                                      <hr>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Name of Shop / Office</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Name of Shop / Office ">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Shop No. / Plot No. / building No.</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Shop No. / Plot No. / building No.">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Complex / Village </label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Complex">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Area /Tehsil</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Area">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Country</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Country">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">State</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="State.">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">City</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="City">
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Pin Code</label>
                                            <input type="text" name="State" class="form-control" id="State" placeholder="Pin Code">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4"></div>
                                    <div class="col-4"></div>
                                    <div class="col-4"></div>
                                </div>
                    
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                              <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>


<style>
  

label:not(.form-check-label):not(.custom-file-label) {
    font-weight: 400 !important;
}

.form-control{
  border-radius:0;
  height: calc(2.25rem + -2px);
}
</style>

<script>
  
$(document).ready(function() {
    $("#maritalStatus").change(function(){
        if ($(this).val() == "married"){
           document.getElementById("domDiv").style.display = "block";
           document.getElementById("spouseDiv").style.display = "flex";
           document.getElementById("iimDiv").style.display = "none";

        }else{
           document.getElementById("domDiv").style.display = "none";
           document.getElementById("spouseDiv").style.display = "none";
           document.getElementById("iimDiv").style.display = "block";
        }
        
    });
  
    $('body').on('change', '#matramonialStatus', function() {
        if ($(this).val() == "no"){
           document.getElementById("martialDetailsDiv").style.display = "none";
        }else{
           document.getElementById("martialDetailsDiv").style.display = "flex";
           // martialDetailsDiv
        }
    });


    $('body').on('change', '#occupations', function() {
        if ($(this).val() == "Service"){
           document.getElementById("shopofficeDiv").style.display = "flex";
        }else{
           document.getElementById("shopofficeDiv").style.display = "none";
           // martialDetailsDiv
        }
    });
  
});
</script>