<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>
<script type="text/javascript" src="//cdn.jsdelivr.net/jquery/1/jquery.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap/latest/css/bootstrap.css" />
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
<style>
	.add-event-form input {
		border: 1.5px solid #45243C;
	} 

	.add-event-form textarea {
		border: 1.5px solid #45243C;
	}

	.add-event-form select {
		border: 1.5px solid #45243C;

	}

	.input-group-append {
		border: 1.5px solid #45243C;
	}

</style>
<section class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<!-- Default box -->
				<div class="card card-primary">
					<div class="card-header">
						<h3 class="card-title col-4"><?php echo $listType;?></h3>
					</div>

					<div>
						<div>
							<div class="card-body login-card-body">
								<div id="msg-div">
									<?php echo $this->session->flashdata('result'); ?>
								</div>
								<form action="<?php echo base_url();?>/event/update/<?php echo $updateData[0]->id;?>" method="post"
									enctype="multipart/form-data" class="add-event-form">
									<label for="Description">Event Date</label>
									<div class="input-group mb-3">

										<?php $main_date = date("m/d/Y", strtotime($updateData[0]->start_event_date))." - ".date("m/d/Y", strtotime($updateData[0]->end_event_date));
                                        echo '<input type="text"  name="olddaterange" value="'.$main_date.'" id="olddaterange" readonly required />';
										?>
									
										<input type="text" class="daterange" name="daterange"  id="daterange" required />

										<div class="input-group-append">
											<div class="input-group-text">
												<span class="fas fa fa-calendar"></span>
											</div>
										</div>
										<div class="icheck-primary">
												<input type="checkbox" id="is_date_update" name="is_date_update">
												<label for="is_date_update">
													Update Date
												</label>
											</div>
									</div>

									<div class="row">
										<div class="col-md-12">
											<label for="Heading">Title/Heading</label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" value="<?php echo $updateData[0]->context;?>" id="context" name="context"
													placeholder="Please type context here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-newspaper"></span>
													</div>
												</div>
											</div>
										</div>
										
									</div>
									<div class="row">
										<div class="col-md-6">
											<label for="Heading">Organiser</label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="organiser" value="<?php echo $updateData[0]->organiser;?>" name="organiser"
													placeholder="Please type organiser here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-newspaper"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Source">Sponsor</label>
											<div class="input-group mb-3">
												<input type="context" class="form-control" id="sponsor" value="<?php echo $updateData[0]->sponsor;?>" name="sponsor"
													placeholder="Please type sponsor name here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-code"></span>
													</div>
												</div>
											</div>
										</div>
									</div>

									<label for="Description">Description</label>
									<div class="input-group mb-3">
										<textarea type="text" id="description" name="description" class="form-control"
											placeholder="Please type description here" required> <?php echo $updateData[0]->description;?></textarea>
										<div class="input-group-append">
											<div class="input-group-text">
												<span class="fas fa fa-comments"></span>
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-md-6">
											<label for="Description">Visible to</label>
											<div class="input-group mb-3">
                                           <select class="form-control" name="visible[]" multiple="multiple" style="border-right: 2px solid;" id="select1"  required>
									<?php 
									$insertedKshetra=json_decode($updateData[0]->kshetra);
									for($j=0;$j<sizeof($kshetraList);$j++){
										if (in_array($kshetraList[$j]->id, $insertedKshetra)) {
                                        // echo '<option value=1 selected> hiiiii</option>';
                               echo'<option value='.(string)$kshetraList[$j]->id.' selected >'.(string)$kshetraList[$j]->kshetra_name.'</option>';
										}else{
                               echo'<option value='.(string)$kshetraList[$j]->id.'>'.(string)$kshetraList[$j]->kshetra_name.'</option>';

										}
									}?>
										</select>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Description">Image</label>
											<div class="input-group mb-3">
												<!-- <input class="form-control"  type="file" name="files[]" multiple="multiple" /> -->
												<input type="file" class="form-control" id="userfile" name="userfile[]"
													multiple="multiple">
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-image"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Description">Image</label>
											<div class="input-group mb-3">
												<!-- <input class="form-control"  type="file" name="files[]" multiple="multiple" /> -->
												<?php  $images=json_decode($updateData[0]->image_name);
										for($i=0; $i<sizeof($images);$i++){	?>
								         <img width="300" height="200" src="<?php echo base_url('assets/images/events/'.$images[$i]);?>" />
										<?php }?>
												
											</div>
										</div>
										<div class="row">
											<div class="form-group col-lg-12 col-md-12 col-xs-12">
												
												<div id="event-image" class="p-2"
													style="border:1px solid #73B3FE; display:none">
												</div>
											</div>
										</div>
									</div>
									<hr>
									<div class="row">
									<div class="col-10">
                                  <div class="icheck-primary">
								 <?php if($updateData[0]->status==1){
								     echo'<input type="checkbox" name ="apply" id="apply" checked>';
								 }else{
								     echo'<input type="checkbox" name ="apply" id="apply">';
								    }?>
										<label for="apply">
											Show on Website / Active
										</label>
									</div>
										</div>
										<div class="col-2">
												<button type="submit" class="btn btn-primary btn-block">Update
													</button>
										</div>
								</form>
							</div>
							<!-- /.login-card-body -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- /.content -->
<!-- /.content-wrapper -->
<script type="text/javascript">
	$('.daterange').daterangepicker();

</script>
<?php include "layouts/footer.php"?>
<script>
	$(function () {
		$(":file").change(function () {
			if (this.files && this.files[0]) {
				for (var i = 0; i < this.files.length; i++) {

					var reader = new FileReader();
					reader.fileName = this.files[i].name;
					reader.onload = imageIsLoaded;
					reader.readAsDataURL(this.files[i]);
					//var fileName=this.files[i].name;// to get filename for uploaded files

				}
			}
		});
	});

	function imageIsLoaded(e) {
		// alert(e.target.fileName);
		document.getElementById('event-image').style.display = 'block';
		var imgSrc = '';
		imgSrc += '&nbsp;<img src=' + e.target.result + ' height="150" width="150" >';
		imgSrc += '';

		$('#event-image').append(imgSrc);
	};

</script>
<script>
	$(document).ready(function () {
		setTimeout(function () {
			$('#msg-div').hide();
		}, 3000);
	});

</script>
