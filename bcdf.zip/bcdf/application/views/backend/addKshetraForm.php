<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>
<style>
	.file_button_container,
	.file_button_container input {
		height: 47px;
		width: 263px;
	}

	.file_button_container_img {
		background: transparent url(http://i.stack.imgur.com/BT5AB.png) left top no-repeat;
	}

	.file_button_container input {
		opacity: 0;
	}

</style>
<style>
.add-news-form input{
	border: 1.5px solid #45243C;
}
.add-news-form textarea{
	border: 1.5px solid #45243C;
}
.add-news-form select{
	border: 1.5px solid #45243C;
	
}
.input-group-append{
	border: 1.5px solid #45243C;
}
</style>
<!-- Main content -->
<section class="content">

	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<!-- Default box -->
				<div class="card card-primary">
					<div class="card-header">
						<h3 class="card-title col-4"><?php echo $listType;?></h3>

					</div>
					<div id="msg-div">
						<?php echo $this->session->flashdata('result'); ?>
					</div>
					<div>
						<div>
							<div class="card-body login-card-body">

								<form action="<?php echo base_url();?>/kshetra/insert" method="post"
									enctype="multipart/form-data" class="add-news-form">
									<div class="row">
										<div class="col-md-6">
											<label for="Heading">Kshetra Name(क्षेत्र का नाम) </label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="k_name" name="k_name"
													placeholder="Please type Kshetra name here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-newspaper"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Source">Kshetra Code(क्षेत्र कोड)</label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="code" name="code"
													placeholder="Please type kshetra code here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-external-link-alt"></span>
													</div>
												</div>
											</div>
										</div>
									</div>	

									<div class="row">
										<div class="col-md-6">
											<label for="Heading">Kshetra Committee Name(क्षेत्र समिति का नाम) </label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="committee_name" name="committee_name"
													placeholder="Please type Committee Title here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-newspaper"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Source">Pin Code(पिन कोड)</label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="pincode" name="pincode"
													placeholder="Please type pincode here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-external-link-alt"></span>
													</div>
												</div>
											</div>
										</div>
									</div>	
									<div class="row">
										<div class="col-md-6">
											<label for="Heading">State(राज्य) </label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="state" name="state"
													placeholder="Please type State here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-newspaper"></span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<label for="Source">District(जिला)</label>
											<div class="input-group mb-3">
												<input type="text" class="form-control" id="district" name="district"
													placeholder="Please type district here" required />
												<div class="input-group-append">
													<div class="input-group-text">
														<span class="fas fa-external-link-alt"></span>
													</div>
												</div>
											</div>
										</div>
									</div>

                                    <hr>
									<div class="row">
										<!-- <div class="col-10">

											<div class="icheck-primary">
												<input type="checkbox" id="apply"name="apply">
												<label for="apply">
													Show on Website / Active
												</label>
											</div>
										</div> -->
										<div class="col-2">
											<button type="submit" class="btn btn-success btn-block">Create Kshetra</button>
										</div>
										<!-- /.col -->
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<!-- /.card -->
			</div>
		</div>
	</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
<script>
	$(function () {
		$(":file").change(function () {
			if (this.files && this.files[0]) {
				for (var i = 0; i < this.files.length; i++) {

					var reader = new FileReader();
					reader.fileName = this.files[i].name;
					reader.onload = imageIsLoaded;
					reader.readAsDataURL(this.files[i]);
					//var fileName=this.files[i].name;// to get filename for uploaded files

				}
			}
		});
	});

	function imageIsLoaded(e) {
		// alert(e.target.fileName);
		document.getElementById('news-image').style.display = 'block';
		var imgSrc = '';
		imgSrc += '&nbsp;<img src=' + e.target.result + ' height="150" width="150" >';
		imgSrc += '';

		$('#news-image').append(imgSrc);
	};

</script>
<script>
	$(document).ready(function(){
		
		setTimeout(function () {
			$('#msg-div').hide();
		}, 3000);
	});

	</script>