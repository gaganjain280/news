<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
	<!-- Brand Logo -->
	<a href="<?php echo base_url();?>assets/backend/index3.html" class="brand-link">

		<img src="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" alt="AdminLTE Logo"
			class="brand-image img-circle elevation-3" style="opacity: .8">
		<span class="brand-text font-weight-light">Asatisamaj</span>
	</a>

	<!-- Sidebar -->
	<div class="sidebar"  style="background: url('<?php echo base_url();?>assets/backend/images/sidebarbg.jpg');background-repeat: no-repeat;background-size:auto 100%">
		<!-- Sidebar user (optional) -->
		<div class="user-panel mt-3 pb-3 mb-3 d-flex">
			<div class="image">
				<img src="<?php echo base_url();?>assets/backend/dist/img/user2-160x160.jpg"
					class="img-circle elevation-2" alt="User Image">
			</div>
			<div class="info">
				<a href="#" class="d-block">Admin</a>
			</div>
		</div>

		<!-- Sidebar Menu -->
		<nav class="mt-2">
			<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon ion ion-person-add"></i>
						<p>
							Members
							<i class="right fas fa-angle-left"></i>
						</p>
					</a>
					<ul class="nav nav-treeview" style="display: none;">
						<li class="nav-item">
							<a href="<?php echo base_url();?>member/add/" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Create Member
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>member/list/1" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									All Active
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>member/list/0" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									All De-Actived
								</p>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa fa-users"></i>
						<p>
							Families
							<i class="right fas fa-angle-left"></i>
						</p>
					</a>
					<ul class="nav nav-treeview" style="display: none;">
						<li class="nav-item">
							<a href="<?php echo base_url();?>family/" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Create Family
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>family/list/1" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>All Active</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>family/list/0" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									All De-Activated
								</p>
							</a>
						</li>
					</ul>
				</li>

				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-handshake"></i>
						<p>
							Committee
							<i class="right fas fa-angle-left"></i>
						</p>
					</a>
					<ul class="nav nav-treeview" style="display: none;">
						<li class="nav-item">
							<a href="<?php echo base_url();?>committe" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Committee
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>committee/Kshetra/0" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Kshetra / City
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>mahasabha" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									All Mahasabha
								</p>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-th"></i>
						<p>
							Publish
							<i class="right fas fa-angle-left"></i>
						</p>
					</a>
					<ul class="nav nav-treeview" style="display: none;">
						<li class="nav-item">
							<a href="<?php echo base_url();?>news/list/0" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									News
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>event/list/0" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Events
								</p>
							</a>
						</li>
					</ul>
				</li>
				<li class="nav-item has-treeview">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-th"></i>
						<p>
							Reminders
							<i class="right fas fa-angle-left"></i>
						</p>
					</a>
					<ul class="nav nav-treeview" style="display: none;">
						<li class="nav-item">
							<a href="<?php echo base_url();?>news/list/0" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Birthdays
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>event/list/0" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Anniversary
								</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url();?>" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>
									Demise
								</p>
							</a>
						</li>
					</ul>
				</li>

				<li class="nav-item">
					<a href="<?php echo base_url();?>" class="nav-link">
						<i class="nav-icon far fa-calendar-alt"></i>
						<p>
							All Sessions
						</p>
					</a>
				</li>

				<li class="nav-item">
					<a href="<?php echo base_url();?>" class="nav-link">
						<i class="fa fa-phone nav-icon"></i>
						<p>
							Contact List
						</p>
					</a>
				</li>
			</ul>
		</nav>
		<!-- /.sidebar-menu -->
	</div>
	<!-- /.sidebar -->
</aside>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1><?=$headTitle?></h1>
				</div>
				<!-- <div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item"><a href="#">Layout</a></li>
						<li class="breadcrumb-item active">Fixed Layout</li>
					</ol>
				</div> -->
			</div>
		</div><!-- /.container-fluid -->
	</section>
