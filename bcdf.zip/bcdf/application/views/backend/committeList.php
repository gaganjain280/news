<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>

<style>
  .news-pagination>.page-item>a {

    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #007bff;
    background-color: #fff;
    border: 1px solid #dee2e6;
    padding: .25rem .5rem;
  }

  .news-pagination>.page-item>strong {

    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #007bff;
    background-color: #fff;
    border: 1px solid #dee2e6;
    padding: .25rem .5rem;
  }

</style>

<section class="content">

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card" style="border:1px solid #343A40">
          <div class="card-header">
            <h3 class="card-title" style="padding:10px;"><?php echo $listType;?></h3>
            <h3 class="float-right"><a href="<?php echo base_url();?>city/addCity"
                class="btn btn-outline-primary btn-sm">Add Nagar</a>
            </h3>
          </div>
          <!-- /.card-header -->
           <div class="container">
                    <div class="row">
                        <div class="col-12">
                          <table id="table_id" class="display">
                              <thead>
                                    <tr>
                                       <th>S.No</th>
                                       <th>Name </th>
                                       <th>Type </th>
                                       <th>Kshetra </th>
                                       <th>City</th>
                                       <th>Action</th>
                                    </tr>
                              </thead>
                              <tbody>
                              </tbody>
                          </table>        
                          </div>
                      </div>
              </div>
          <div class="card-footer clearfix" style="">

          </div>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
</div>
<!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
 <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js" type="text/javascript"></script>
<script>
   $(document).ready(function(){
      var base_url = "<?php echo base_url();?>"; // You can use full url here but I prefer like this
       tHtml="";
        $.ajax({
            type: "POST",
            url: base_url+'CommitteeController/getCommitteList',
            crossDomain: true,
            cache: false,
            // dataType: 'JSON',
            success: function (result) {
              var getObject = JSON.parse(result);
                $.each(getObject, function (i, item) {
                   var  id = item['id'];
                    var name = item['name'];
                    if(item['type']==2){
                    var type = 'Committee';
                    }else if(item['type']==3){
                    var type = 'Nagar';
                    }else if(item['type']==1){
                    var type = 'Mahasabha';
                    }else{
                    var type = 'Not valid'; 
                    }
                    if(item['nagar_id']=='0'){
                        var nagar_id = '';
                    }else{
                        var nagar_id = item['nagar_id'];
                    }
                    var kshetra_id = item['kshetra_id'];
                    // var kshetra_id = item['kshetra_id'];
                    tHtml += "<tr><td >" + (i+1)+ "</td><td  style='font-weight:600'>" + name+ "</td><td class='text-uppercase' style='font-weight:600'>" + type + "</td><td class='text-uppercase' style='font-weight:600'>" + kshetra_id + "</td><td class='text-uppercase' style='font-weight:600'>" + nagar_id + "</td><td class='text-uppercase' style='font-weight:600'><a class='btn btn-primary btn-sm' href='<?php echo base_url();?>city/updateCityForm/"+id+"'>View Member</a></td>";
                        tHtml += "</tr>";
                });

                $('#table_id tbody').html(tHtml);
            }
        }); //end ajax

 $('#table_id').DataTable();
  
   });


</script>

