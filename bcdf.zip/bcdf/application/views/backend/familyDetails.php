<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>



<!-- Main content -->
<section class="content">


	<!-- Default box -->
	<div class="card card-solid">
		<div class="card-body pb-0">
			<?php if( $feedback = $this->session->flashdata('feedback')){ 
            $feedback_class = $this->session->flashdata('feedback_class');
          ?>
			<div class="alert alert-dismissible <?= $feedback_class ?>">
				<?= $feedback ?>
			</div>
			<?php } ?>
			<div class="row">
				<div class="col-12 col-sm-12 col-md-12">
					<div class="row d-flex align-items-stretch">
						<div class="col-12 col-sm-12 col-md-12 d-flex align-items-stretch">
							<div class="card bg-light" style="width: 100%">
								<div class="card-header text-muted border-bottom-0 text-center">
									<h4> Family Profile</h4>
								</div>
								<div class="card-body pt-0">
									<div class="row">
											<div class="col-md-4 col-sm-12 text-center">
												<div class="card card-widget widget-user" style="border-radius: 15px;">
													<img src="<?php echo base_url();?>assets/backend/dist/img/user1-128x128.jpg"
													alt="" class="img-thumbnail img-fluid" width="100%" style="height:250px;border-radius: 15px;padding: 0;">
													<div class="card-footer" style="padding-top:12px;">
														<div class="row" style="background-color:#FF9800;border-radius: 10px;color:white">
															<div class="col-sm-12">
																<div class="description-block">
																	<span class="description-text">Family Name</span>
																	<h5 class="description-header text-uppercase"><?=$family->f_name?></h5>
																	<h5 class="description-header text-uppercase">[ <?=$family->f_asati_id?> ]</h5>
																</div>
																<!-- /.description-block -->
															</div>
														</div>
														<!-- /.row -->
													</div>
												</div>
											</div>
											<div class="col-md-4 col-sm-12">
												<div class="card card-widget widget-user-2" style="border-radius: 15px;">
													<!-- Add the bg color to the header using any of the bg-* classes -->
													<div class="widget-user-header" style="background-color:#FF9800;color:#fff">
														<h3 class="widget-user-username m-0"><?=$family->f_name?></h3>
														<h5 class="widget-user-desc m-0">( Family Head )</h5>
													</div>
													<div class="card-footer p-0">
														<ul class="nav flex-column">
														
														<li class="nav-item">
															<a href="#" class="nav-link">
															Indigenous People : <b class="float-right"><?=$family->f_indigeneous?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Gotra : <b class="float-right"><?=$family->f_gotra?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Dynasty : <b class="float-right"><?=$family->f_dynasty?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Kshetra : <b class="float-right"><?=$family->kshetra_name?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Nagar : <b class="float-right"><?=$family->nagar?></b>
															</a>
														</li>
														</ul>
													</div>
												</div>
											</div>
											<div class="col-md-4 col-sm-12">
											<div class="card card-widget widget-user-2" style="border-radius: 15px;">
													<!-- Add the bg color to the header using any of the bg-* classes -->
													<div class="widget-user-header" style="background-color:#FF9800;color:#fff">
														<h3 class="widget-user-username m-0">Address Details :</h3>
													</div>
													<div class="card-footer p-0">
														<ul class="nav flex-column">
														
														<li class="nav-item">
															<a href="#" class="nav-link">
															House No : <b class="float-right"><?=$family->house_no?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															House Name : <b class="float-right"><?=$family->house_name?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Colony / Village : <b class="float-right"><?=$family->colony?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Pin Code : <b class="float-right"><?=$family->pincode?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Area /Tehsil : <b class="float-right"><?=$family->area?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															City : <b class="float-right"><?=$family->city?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															State : <b class="float-right"><?=$family->state?></b>
															</a>
														</li>
														<li class="nav-item">
															<a href="#" class="nav-link">
															Country : <b class="float-right"><?=$family->country?></b>
															</a>
														</li>
														</ul>
													</div>
												</div>
											</div>
										
									</div>
								</div>
								<div class="card-footer" style="background-color:#FF9800">
									<div class="text-right">
										<a href="#" class="btn btn-sm btn-primary" data-toggle="modal"
											data-target="#modal-xl">
											<i class="fas fa-user"></i> UPDATE DETAILS
										</a>
									</div>
								</div>
							</div>
						</div>



						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-building"></i></span> Address: Demo
													Street 123, Demo City 04312, NJ</li>
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-phone"></i></span> Phone #: + 800 - 12
													12 23 52</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user2-160x160.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-building"></i></span> Address: Demo
													Street 123, Demo City 04312, NJ</li>
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-phone"></i></span> Phone #: + 800 - 12
													12 23 52</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user1-128x128.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-building"></i></span> Address: Demo
													Street 123, Demo City 04312, NJ</li>
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-phone"></i></span> Phone #: + 800 - 12
													12 23 52</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user2-160x160.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-phone"></i></span> Phone #: + 800 - 12
													12 23 52</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user1-128x128.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-building"></i></span> Address: Demo
													Street 123, Demo City 04312, NJ</li>
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-phone"></i></span> Phone #: + 800 - 12
													12 23 52</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user1-128x128.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-building"></i></span> Address: Demo
													Street 123, Demo City 04312, NJ</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user1-128x128.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-building"></i></span> Address: Demo
													Street 123, Demo City 04312, NJ</li>
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-phone"></i></span> Phone #: + 800 - 12
													12 23 52</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user1-128x128.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12 col-sm-6 col-md-4 d-flex align-items-stretch">
							<div class="card bg-light">
								<div class="card-header text-muted border-bottom-0">
									Digital Strategist
								</div>
								<div class="card-body pt-0">
									<div class="row">
										<div class="col-7">
											<h2 class="lead"><b>Nicole Pearson</b></h2>
											<p class="text-muted text-sm"><b>About: </b> Web Designer / UX / Graphic
												Artist / Coffee Lover </p>
											<ul class="ml-4 mb-0 fa-ul text-muted">
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-building"></i></span> Address: Demo
													Street 123, Demo City 04312, NJ</li>
												<li class="small"><span class="fa-li"><i
															class="fas fa-lg fa-phone"></i></span> Phone #: + 800 - 12
													12 23 52</li>
											</ul>
										</div>
										<div class="col-5 text-center">
											<img src="<?php echo base_url();?>assets/backend/dist/img/user2-160x160.jpg"
												alt="" class="img-circle img-fluid">
										</div>
									</div>
								</div>
								<div class="card-footer">
									<div class="text-right">
										<a href="#" class="btn btn-sm bg-teal">
											<i class="fas fa-comments"></i>
										</a>
										<a href="#" class="btn btn-sm btn-primary">
											<i class="fas fa-user"></i> View Profile
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-footer">
			<nav aria-label="Contacts Page Navigation">
			</nav>
		</div>
		<!-- /.card-footer -->
	</div>
	<!-- /.card -->

</section>
<!-- /.content -->
<!-- /.content -->
</div>
<!-- /.content-wrapper -->


<div class="modal fade" id="modal-xl">
	<div class="modal-dialog modal-xl">
		<div class="modal-content">
			<!--        <div class="modal-header">
              <h4 class="modal-title">Extra Large Modal</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div> -->
			<div class="modal-body">
				<div class="row">
					<div class="col-12 col-sm-12 col-md-12">
						<div class="card card-primary">
							<div class="card-header">
								<h3 class="card-title">Update Family Details </h3>
							</div>
							<!-- /.card-header -->
							<!-- form start -->
							<form role="form" action="<?=base_url()?>family/update" method="POST">
								<input type="hidden" name="family_id" value="<?=$family->id?>">
								<div class="card-body">
									<div class="row">
										<div class="col-4">
											<div class="form-group">
												<label for="exampleInputEmail1">Family Name (परिवार का नाम) *</label>
												<input type="familyName" class="form-control" id="familyName"
													name="familyName" value="<?=$family->f_name?>"
													placeholder="Family Name">
											</div>
										</div>
										<div class="col-4">
											<div class="form-group">
												<label for="">Select Kshetra / क्षेत्र का चयन करें *</label>
												<select class="form-control" name="kshetra" id="kshetra">

													<?php
                                                  $kshetra = $this->db->get('kshetra')->result_array();
                                                  foreach($kshetra as $row):
                                                ?>
													<?php 
                                                  if ($row['id'] == $family->kshetra_id) {
                                                    $selected = "selected";
                                                   
                                                  }else{
                                                    $selected = "";
                                                  }
                                                ?>
													<option <?=$selected; ?> value="<?php echo $row['id'];?>">
														<?php echo $row['kshetra_name'];?></option><?php endforeach; ?>
												</select>
											</div>
										</div>
										<div class="col-4">
											<div class="form-group">
												<label for="exampleInputPassword1">Select Nagar Samiti (नगर समिति
													चुने)</label>
												<select class="form-control" name="nagar" id="nagar"></select>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-4">
											<div class="form-group">
												<label for="exampleInputPassword1">Indigenous People (मूल निवासी)
													*</label>
												<input type="text" name="Indigenous" value="<?=$family->f_indigeneous?>"
													class="form-control" id="Indigenous" placeholder="Indigenous">
											</div>
										</div>
										<div class="col-4">
											<div class="form-group">
												<label for="exampleInputPassword1">Gotra (गोत्र) *</label>
												<input type="text" name="Gotra" value="<?=$family->f_gotra?>"
													class="form-control" id="Gotra" placeholder="Gotra">
											</div>
										</div>
										<div class="col-4">
											<div class="form-group">
												<label for="exampleInputPassword1">Dynasty (वंश)</label>
												<input type="text" name="Dynasty" value="<?=$family->f_dynasty?>"
													class="form-control" id="Dynasty" placeholder="Dynasty">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-3">
											<div class="form-group">
												<label for="">House No / मकान नंबर</label>
												<input type="text" value="<?=$family->house_no?>" name="house_no"
													class="form-control" id="house_no" placeholder="House No">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="">House Name / घर का नाम </label>
												<input type="text" value="<?=$family->house_name?>" name="house_name"
													class="form-control" id="house_name" placeholder="House Name ">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="">Colony / Village (कालोनी / गाँव) </label>
												<input type="text" value="<?=$family->colony?>" name="colony"
													class="form-control" id="colony" placeholder="Colony">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="">Pin Code / पिन कोड</label>
												<div class="autocomplete">
													<input type="text" name="pincode" value="<?=$family->pincode?>"
														class="form-control" id="pincode" placeholder="Pin Code">
													<div id="pincodeautocomplete-list" class="autocomplete-items"></div>
												</div>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="">Area /Tehsil (क्षेत्र / तहसील)</label>
												<input type="text" value="<?=$family->area?>" name="area"
													class="form-control" id="area" placeholder="Area">
											</div>
										</div>

										<div class="col-md-3">
											<div class="form-group">
												<label for="">City / शहर</label>
												<input type="text" value="<?=$family->city?>" name="city"
													class="form-control" id="city" placeholder="City">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="">State / राज्य</label>
												<input type="text" value="<?=$family->state?>" name="state"
													class="form-control" id="state" placeholder="State.">
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="">Country / देश</label>
												<input type="text" value="<?=$family->country?>" name="country"
													class="form-control" id="country" placeholder="Country">
											</div>
										</div>

									</div>
									<div class="row">
										<div class="col-4"></div>
										<div class="col-4"></div>
										<div class="col-4"></div>
									</div>

								</div>
								<!-- /.card-body -->

								<div class="card-footer">
									<button type="submit" class="btn btn-primary">Save changes</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->







<?php include "layouts/footer.php"?>

<script>
	$(document).ready(function () {

		var k_id = < ? = $family - > kshetra_id ? > ;

		$.ajax({
			url: "<?php echo site_url('family/nagarbyid');?>",
			method: "POST",
			data: {
				id: k_id
			},
			async: true,
			dataType: 'json',
			success: function (data) {
				var html = '';
				var i;
				for (i = 0; i < data.length; i++) {
					if ( < ? = $family - > nagar_id ? > == data[i].id) {
						html += '<option selected value=' + data[i].id + '>' + data[i].nagar +
							'</option>';
					} else {
						html += '<option value=' + data[i].id + '>' + data[i].nagar + '</option>';
					}
				}
				$('#nagar').html(html);
			}
		});









		$("#kshetra").change(function () {
			var id = this.value;
			$.ajax({
				url: "<?php echo site_url('family/nagarbyid');?>",
				method: "POST",
				data: {
					id: id
				},
				async: true,
				dataType: 'json',
				success: function (data) {
					var html = '';
					var i;
					html += '<option disabled  selected="selected"> Select Nagar</option>';
					for (i = 0; i < data.length; i++) {
						html += '<option value=' + data[i].id + '>' + data[i].nagar +
							'</option>';
					}
					$('#nagar').html(html);
				}
			});
			return false;
		});


		$("#pincode").keyup(function () {
			var str = this.value;
			if (str !== "") {
				$.ajax({
					url: "<?php echo site_url('pincode');?>",
					method: "POST",
					data: {
						str: str
					},
					async: true,
					dataType: 'json',
					success: function (data) {
						console.log(data);
						var html = '';
						for (i = 0; i < data.length; i++) {
							html += '<div  class="pincodeAutoload" pincode="' + data[i][
									'pincode'
								] + '" officename="' + data[i]['officename'] +
								'" statename="' + data[i]['statename'] + '" off="' + data[i][
									'off'
								] + '" districtname="' + data[i]['districtname'] + '">' + data[
									i]['pincode'] + ',' + data[i]['officename'] +
								'<input type="hidden" value="' + data[i] + '"></div>';
						}
						$('#pincodeautocomplete-list').html(html);
					}
				});

			}
			// return false;
		});

		$('body').on('click', '.pincodeAutoload', function () {
			$('#pincode').val($(this).attr('pincode'));
			$('#area').val($(this).attr('officename'));
			$('#state').val($(this).attr('statename'));
			$('#city').val($(this).attr('districtname'));
			$('#pincodeautocomplete-list').html('');
		});
	});

</script>


<style>
	#pincodeautocomplete-list {
		max-height: 300px;
		overflow-y: scroll;
	}

	.autocomplete-items {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		/*top: 100%;*/
		left: 0;
		right: 0;
	}

	.autocomplete-items div {
		padding: 10px;
		cursor: pointer;
		background-color: #fff;
		border-bottom: 1px solid #d4d4d4;
	}

	/*when hovering an item:*/
	.autocomplete-items div:hover {
		background-color: #e9e9e9;
	}

	/*when navigating through the items using the arrow keys:*/
	.autocomplete-active {
		background-color: DodgerBlue !important;
		color: #ffffff;
	}

</style>
