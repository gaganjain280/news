<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?php echo $listType;?></h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
                </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered">
                    <thead>                  
                      <tr>
                        <th>S.No</th>
                        <th>Name </th>
                        <th>Family Name </th>
                        <th>DOB</th>
                        <th>Age</th>
                        <th>Mobile No</th>
                        <th>Kshetra</th>
                        <th>City </th>
                        <th>Member</th>
                        <th>Family</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                          <td>1      </td>
                          <td>randip Asati  </td>
                          <td>randip</td>
                          <td>1964-10-20 </td>
                          <td>20 </td>
                          <td>9421709519 </td>
                          <td>  Gondia  </td>
                          <td>Amgaon </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> <tr>
                          <td>2      </td>
                          <td>Amrata Nayak  </td>
                          <td>randip</td>
                          <td>1980-10-20 </td>
                          <td>30</td>
                          <td>9426455565 </td>
                          <td> Jabalpur </td>
                          <td>Jabalpur </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> <tr>
                          <td>3     </td>
                          <td>Shefali </td>
                          <td>randip</td>
                          <td>1994-10-20 </td>
                          <td>26 </td>
                          <td>9852585519 </td>
                          <td>  bhopal  </td>
                          <td>bhopal </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> <tr>
                          <td>4     </td>
                          <td>Dev  </td>
                          <td>jain</td>
                          <td>1990-10-20 </td>
                          <td>30 </td>
                          <td>9421745619 </td>
                          <td>  nagda  </td>
                          <td>nagda </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <a href="" class="btn btn-outline-info">View</a>    </td>
                          <td> <input type="checkbox" name="my-checkbox" checked data-bootstrap-switch> </td>
                        </tr> 
                    </tbody>
                </table>
              </div>
              <!-- /.card-body -->
               <div class="card-footer clearfix">
                <ul class="pagination pagination-sm m-0 float-right">
                  <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                </ul>
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
