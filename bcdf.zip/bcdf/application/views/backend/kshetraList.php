<?php include "layouts/header.php"?>
<?php include "layouts/sidebar.php"?>

<style>
  .news-pagination>.page-item>a {

    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #007bff;
    background-color: #fff;
    border: 1px solid #dee2e6;
    padding: .25rem .5rem;
  }

  .news-pagination>.page-item>strong {

    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #007bff;
    background-color: #fff;
    border: 1px solid #dee2e6;
    padding: .25rem .5rem;
  }

</style>

<!-- Main content -->
<section class="content">

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <!-- Default box -->
        <div class="card" style="border:1px solid #343A40">
          <div class="card-header">
            <h3 class="card-title" style="padding:10px;"><?php echo $listType;?></h3>
            <h3 class="float-right"><a href="<?php echo base_url();?>kshetra/addKshetra"
                class="btn btn-outline-primary btn-sm">Add Kshetra</a>
            </h3>
          </div>
          <!-- /.card-header -->
           <div class="container">
                    <div class="row">
                        <div class="col-12">
                          <table class="table" id="datatable">
                              <thead>
                                  <tr>
                                       <th>S.No</th>
                                       <th>Kshetra </th>
                                       <th>State </th>
                                       <th>Created Date </th>
                                       <th>Action </th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>                
                          </div>
                      </div>
                  </div>
          <!-- /.card-body -->
          <div class="card-footer clearfix" style="">

          </div>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
</div>
<!-- /.content-wrapper -->

<?php include "layouts/footer.php"?>
 <script>
    $(document).ready(function(){
   $.getScript("https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js" , function(){   
   $.getScript("https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" , function(){   
     $.getScript("https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" , function(){  
     $.getScript("https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js" , function(){  
       $( function() {
        var base_url = "<?php echo base_url();?>"; // You can use full url here but I prefer like this
            $('#datatable').DataTable({
               "pageLength" : 10,
               "serverSide": true,
               "order": [[0, "asc" ]],
               "ajax":{
                        url :  base_url+'CommitteeController/kshetarDataTableList',
                        // url :  base_url+'CommitteeController/kshetarDataTableList',
                        type : 'POST'
                      },
            }); // End of DataTable
       } );
     });
     });
     });
   });
  });
  </script>
