	<footer id="footer">
		<!-- Footer-Top -->
		<div class="footer_top primary-bg">
			<div class="container">
				<div class="row">
					<div class="col-md-6 top_widget">
						<div class="footer_logo">
							<a href="index.html"><img style="height:50px;border-radius:50%" src="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" class="img-circle" width="40" height="40"><span style="color:white">&nbsp;&nbsp; Akhil Bhartiya Asati Mahasabha</span></a>
						</div>
					</div>
					<div class="col-md-6 top_widget">
						<div class="follow_us">
							<ul class="text-custom-align-right">
								<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
								<li><a href="#"><i class="fab fa-youtube"></i></a></li>
								<li><a href="#"><i class="fab fa-instagram"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Footer-Top -->

		<!-- Footer-Widgets -->
		<div class="container">
			<div class="row">
				<div class="col-md-4 footer_widget">
					<div class="widget_inner">
						<h5 style="text-align:center">Contact Us</h5>
						<p>E: <a href="">contact@asatisamaj.com</a></p>
						<p>P: +91 92292 21197</p>
					</div>
				</div>
				<div class="col-md-4 footer_widget">
				<h5 style="text-align:center">Total Visitors</h5>
					<center>
					<img src="http://hitwebcounter.com/counter/counter.php?page=7155985&amp;style=0025&amp;nbdigits=7&amp;type=page&amp;initCount=0" title="" alt="" border="0">
					</center>
				</div>
				<div class="col-md-4 footer_widget">
					<div class="widget_inner">
						<h5 style="text-align:center">Useful Links</h5>
						<div class="footer_nav">
							<ul>
								<li><a href="#">FAQ</a></li>
								<li><a href="#">Account</a></li>
								<li><a href="#">Privacy Policy</a></li>
								<li><a href="#">Matrimony</a></li>
								<li><a href="#">Festivals</a></li>
								<li><a href="#">Donations</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Footer-Widgets -->

		<!-- Footer-Bottom -->
		<div class="footer_bottom">
			<div class="container">
				<div class="row">
					<div class="col-md-4 align-self-center">
						<p class="mb-0">&copy; 2020 Akhil Bhartiya Asati Mahasabha</p>
					</div>
					<div class="col-md-4 align-self-center">
						<div id="back-top" class="back-top">
							<a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i> </a>
						</div>
					</div>
					<div class="col-md-4 align-self-center">
						<div class="footer_links">
							<a href="#">Home</a>
							<a href="about-us.html">About Us</a>
							<a href="sermon.html">Sign In</a>
							<a href="events.html">Register</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Footer-Bottom -->
	</footer>
	<!-- /Footer -->

	<!-- Scripts -->
	<script src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url();?>/assets/js/bootstrap.min.js"></script>
	<!--Magnific-Popup-JS-->
	<script src="<?php echo base_url();?>/assets/js/jquery.magnific-popup.min.js"></script>
	<!-- Countdown -->
	<script src="<?php echo base_url();?>/assets/js/jquery.countdown.min.js"></script>
	<!--Custome-JS-->
	<script src="<?php echo base_url();?>/assets/js/interface.js"></script>
	<!--Carousel-JS-->
	<script src="<?php echo base_url();?>/assets/js/owl.carousel.min.js"></script>
	<!--Audio-JS-->
	<script src="<?php echo base_url();?>/assets/js/slick.min.js"></script>
	<!--ion-range-slider-JS-->
	<script src="<?php echo base_url();?>/assets/js/ion.rangeSlider.min.js"></script>
	<!--Audio-JS-->
	<script src="<?php echo base_url();?>/assets/js/audio_custome.js"></script>
</body>

</html>
