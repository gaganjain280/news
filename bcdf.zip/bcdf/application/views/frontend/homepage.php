<?php include "header.php"?>
<style>
.table td, .table th{
	padding: 0px;
}
.box_wrap{
	border-color: #45243C;
}
</style>
<!-- Intro -->
	<section id="intro">
		<div class="overlay overlay-bg"></div>
		<div class="owl-carousel">
			<div class="item section-padding" style="background-image:url(<?php echo base_url();?>assets/images/banner-1.png);">
				<div class="container">
					<div class="intro_text white_text">
						<h1>ईश्वर हमारे भीतर है !</h1>
						<p>ॐ भूर् भुवः स्वः। तत् सवितुर्वरेण्यं। भर्गो देवस्य धीमहि। धियो यो नः प्रचोदयात् ॥ </p>
						<a href="#" class="btn dark-btn tilak-top-btn">जानिए समाज के बारे में</a>
					</div>
				</div>
			</div>
			<div class="item section-padding" style="background-image:url(<?php echo base_url();?>assets/images/banner-2.jpeg);">
				<div class="container">
					<div class="intro_text white_text">
						<h1>ईश्वर हमारे भीतर है !</h1>
						<p>ॐ भूर् भुवः स्वः। तत् सवितुर्वरेण्यं। भर्गो देवस्य धीमहि। धियो यो नः प्रचोदयात् ॥ </p>
						<a href="#" class="btn dark-btn tilak-top-btn">जानिए समाज के बारे में</a>
					</div>
				</div>
			</div>
			<div class="item section-padding" style="background-image:url(<?php echo base_url();?>assets/images/banner-3.jpg);">
				<div class="container">
					<div class="intro_text white_text">
						<h1>हम ईश्वर की कृपा के पात्र हैं!</h1>
						<p>ॐ भूर् भुवः स्वः। तत् सवितुर्वरेण्यं। भर्गो देवस्य धीमहि। धियो यो नः प्रचोदयात् ॥ </p>
						<a href="#" class="btn dark-btn tilak-top-btn">जानिए समाज के बारे में</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- /Intro-->
	<!-- Latest-Events-Sermons -->
	<section class="section-padding latest_event_sermons m-0">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-6">
					<div class="heading">
						<h3>Latest News</h3>
					</div>
					<div class="event_list event-slider slick-vertical">
						<div class="event-slider-item pb-4">
							<div class="row">
								<div class="col-12">
									<div class="event-list">
										<ul>
											<li>
												<div class="event_info">
													<div class="event_date">
														<span>26</span> feb'20
													</div>
													<h6><a href="#">समाज की बेटियों सोनम असाटी एवं प्रिन्सी असाटी ने कंपनी सेक्रेटरी फाइनल की परिक्षा उतरीण की</a></h6>
													<ul>
														<li><i class="far fa-clock"></i>समाज की दो बेटियों सोनम असाटी एवं प्रिन्सी असाटी ने कंपनी सेक्रेटरी फाइनल की परिक्षा उतरीण कर उनके परिवार तथा हम सभी समाज बन्धुओ को गौरवान्वित किया है। दोनों बेटियों के साथ साथ उनके परिवार को हार्दिक हार्दिक बधाई एवं शुभकामनाएं*💐 🙏 बेटी पढ़ाओ बेटी बढ़ाओ🙏</li>
													</ul>
												</div>
											</li>
											<li>
												<div class="event_info">
													<div class="event_date">
														<span>23</span> feb'19
													</div>
													<h6><a href="#">महासभा का नया बायलॉज (नियमावली) आपके अवलोकनार्थ वेबसाइट के माध्यम से pdf फ़ाइल में प्रेषित किया जा रहा है।</a></h6>
													<ul>
														<li><i class="far fa-clock"></i>नया महासभा का बायलॉज (नियमावली) आपके अवलोकनार्थ वेबसाइट के माध्यम से pdf फ़ाइल में प्रेषित किया जा रहा । इसमें आपको अखिल भारतीय असाटी समाज के क्षेत्रवार नगर एवं ग्राम के परिसीमन की जानकारी प्राप्त होगी। <br>Menu > Books > Constitution</li>
													</ul>
												</div>
											</li>
										</ul>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" align="center">
					<div class="card">
						<div class="header">
							<h2 style="margin-bottom:5px">
								Members Registered
							</h2>
						</div>
						<div>
							<table class="table table-bordered table-striped" style="margin-bottom:0px" id="">
								<thead style="background-color:#45243C;color:#fff;text-align:center">
									<tr>
										<th style="color:#fff">REGIONs</th>
										<th style="color:#fff">FAMILIES</th>
										<th style="color:#fff">MEMBERS</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>Jabalpur</td>
										<td style="font-weight:600;text-align:center">430</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">1970</td>
									</tr>
									<tr>
										<td>Tikamgarh</td>
										<td style="font-weight:600;text-align:center">248</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">1336</td>
									</tr>
									<tr>
										<td>Balaghat</td>
										<td style="font-weight:600;text-align:center">124</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">675</td>
									</tr>
									<tr>
										<td>Khargapur-Baldeogarh</td>
										<td style="font-weight:600;text-align:center">125</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">586</td>
									</tr>
									<tr>
										<td>Gondia</td>
										<td style="font-weight:600;text-align:center">101</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">314</td>
									</tr>
									<tr>
										<td>Damoh</td>
										<td style="font-weight:600;text-align:center">93</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">286</td>
									</tr>
									<tr>
										<td>Sagar - Banda</td>
										<td style="font-weight:600;text-align:center">59</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">220</td>
									</tr>
									<tr>
										<td>Bhopal</td>
										<td style="font-weight:600;text-align:center">57</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">199</td>
									</tr>
									<tr>
										<td>Katni</td>
										<td style="font-weight:600;text-align:center">45</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">146</td>
									</tr>
									<tr>
										<td>Chattarpur </td>
										<td style="font-weight:600;text-align:center">50</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">125</td>
									</tr>
									<tr>
										<td>Bada Malhera</td>
										<td style="font-weight:600;text-align:center">43</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">111</td>
									</tr>
									<tr>
										<td>Chhattisgarh</td>
										<td style="font-weight:600;text-align:center">30</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">89</td>
									</tr>
									<tr>
										<td>Indore</td>
										<td style="font-weight:600;text-align:center">24</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">78</td>
									</tr>
									<tr>
										<td>Hirapur - Shahgarh</td>
										<td style="font-weight:600;text-align:center">31</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">71</td>
									</tr>
									<tr>
										<td>Hata-Amanganj</td>
										<td style="font-weight:600;text-align:center">14</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">35</td>
									</tr>
									<tr>
										<td>Khurai-Bina</td>
										<td style="font-weight:600;text-align:center">8</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">33</td>
									</tr>
									<tr>
										<td>Bijawar-Satai</td>
										<td style="font-weight:600;text-align:center">9</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">32</td>
									</tr>
									<tr>
										<td>Pune</td>
										<td style="font-weight:600;text-align:center">4</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">11</td>
									</tr>
									<tr>
										<td>Out Of India</td>
										<td style="font-weight:600;text-align:center">1</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">1</td>
									</tr>
									<tr>
										<td>Regions : 23</td>
										<td style="font-weight:600;text-align:center">1528</td>
										<td class="text-uppercase" style="font-weight:600;text-align:center">6393 </td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- /Latest-Events-Sermons -->
	<!-- Team -->
	<section class="section-padding" id="about-team" style="margin-top:-90px" >
		<div class="container">
			<div class="our_team">
				<div class="section-header text-center">
					<h2>हमारी समिति</h2>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="owl-carousel team-carousel">
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c1.jpg" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>अशोक गुप्ता</h6>
									<p>( अध्यक्ष )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c2.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>केसी असाटी</h6>
									<p>( उपाध्यक्ष  )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c3.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>पन्ना लाल ज्वारीय</h6>
									<p>( उपाध्यक्ष  )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c4.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>मुरारी असाटी</h6>
									<p>( उपाध्यक्ष  )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c5.jpg" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>शैलेंद्र गुप्ता</h6>
									<p>( महासचिव )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c6.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>राजकुमार असाटी</h6>
									<p>( कोषाध्यक्ष )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c7.jpg" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>मनीष असाटी</h6>
									<p>( प्रवक्ता व्यक्ति )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c8.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>डॉ रमेश असाटी</h6>
									<p>( मुख्य संरक्षक )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c9.jpg" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>आर.आर. असाटी</h6>
									<p>( संरक्षक )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c10.jpeg" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>दिलीप असाटी</h6>
									<p>( मंत्री )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c11.jpeg" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>शैलेष असाटी</h6>
									<p>( मंत्री )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c12.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>जितेंद्र असाटी</h6>
									<p>( प्रचार सचिव )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c13.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>दिलीप नायक</h6>
									<p>( संगठन मंत्री )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c14.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>राजेश नायक</h6>
									<p>( संयुक्त सचिव )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c15.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>सतीश गुप्ता</h6>
									<p>( युवा अध्यक्ष )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c16.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>मीना सुनील असाटी</h6>
									<p>( अध्यक्ष - महिला विंग )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c17.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>ओमप्रकाश असाटी</h6>
									<p>( संयोजक - शिक्षा समिति )</p>
								</div>
							</div>
							<div class="item">
								<div class="box_wrap">
									<div class="team_img">
										<img src="<?php echo base_url();?>assets/images/members/c18.png" alt="image">
										<div class="team_url"><a href="#"><i class="fa fa-plus"></i></a></div>
									</div>
									<h6>पीपी जुरिया</h6>
									<p>( संयोजक - अविवाहित प्रकोष्ठ )</p>
								</div>
							</div>
							
						</div>
					</div>

				</div>

			</div>
		</div>
	</section>
	<!-- /Team -->
	<!-- Latest-Blog -->
	<section class="latest_blog section-padding" id="blog">
		<div class="container">
			<div class="blog">
				<div class="section-header text-center">
					<h2>Latest Events</h2>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="owl-carousel">
							<div class="item">
								<article class="blog-section">
									<div class="blog_wrap">
										<div class="blog_img">
											<a href="#"><img src="https://via.placeholder.com/357x188" alt="image"></a>
										</div>
										<div class="blog_info">
											<div class="post_date"><a href="#">sep 01, 2019</a></div>
											<h5><a href="#">haridwar at night</a></h5>
											<p>You need to be sure there isn't anything embarrassing hidden in the middle of text.
												All the Lorem Ipsum generators on the Internet tend to repeat predefined</p>
											<a href="#" class="btn">Read More <i class="fa fa-caret-right"></i> </a>
										</div>
									</div>
								</article>
							</div>

							<div class="item">
								<article class="blog-section">
									<div class="blog_wrap">
										<div class="blog_img">
											<a href="#"><img src="https://via.placeholder.com/357x188" alt="image"></a>
										</div>
										<div class="blog_info">
											<div class="post_date"><a href="#">Aug 28, 2019</a></div>
											<h5><a href="#">chaar dhaam yatra</a></h5>
											<p>You need to be sure there isn't anything embarrassing hidden in the middle of text.
												All the Lorem Ipsum generators on the Internet tend to repeat predefined</p>
											<a href="#" class="btn">Read More <i class="fa fa-caret-right"></i> </a>
										</div>
									</div>
								</article>
							</div>

							<div class="item">
								<article class="blog-section">
									<div class="blog_wrap">
										<div class="blog_img">
											<a href="#"><img src="https://via.placeholder.com/357x188" alt="image"></a>
										</div>
										<div class="blog_info">
											<div class="post_date"><a href="#">sep 10, 2019</a></div>
											<h5><a href="#">Vaishno Devi at night</a></h5>
											<p>You need to be sure there isn't anything embarrassing hidden in the middle of text.
												All the Lorem Ipsum generators on the Internet tend to repeat predefined</p>
											<a href="#" class="btn">Read More <i class="fa fa-caret-right"></i> </a>
										</div>
									</div>
								</article>
							</div>

							<div class="item">
								<article class="blog-section">
									<div class="blog_wrap">
										<div class="blog_img">
											<a href="#"><img src="https://via.placeholder.com/357x188" alt="image"></a>
										</div>
										<div class="blog_info">
											<div class="post_date"><a href="#">sep 01, 2019</a></div>
											<h5><a href="#">haridwar at night</a></h5>
											<p>You need to be sure there isn't anything embarrassing hidden in the middle of text.
												All the Lorem Ipsum generators on the Internet tend to repeat predefined</p>
											<a href="#" class="btn">Read More <i class="fa fa-caret-right"></i> </a>
										</div>
									</div>
								</article>
							</div>

							<div class="item">
								<article class="blog-section">
									<div class="blog_wrap">
										<div class="blog_img">
											<a href="#"><img src="https://via.placeholder.com/357x188" alt="image"></a>
										</div>
										<div class="blog_info">
											<div class="post_date"><a href="#">Aug 28, 2019</a></div>
											<h5><a href="#">chaar dhaam yatra</a></h5>
											<p>You need to be sure there isn't anything embarrassing hidden in the middle of text.
												All the Lorem Ipsum generators on the Internet tend to repeat predefined</p>
											<a href="#" class="btn">Read More <i class="fa fa-caret-right"></i> </a>
										</div>
									</div>
								</article>
							</div>

							<div class="item">
								<article class="blog-section">
									<div class="blog_wrap">
										<div class="blog_img">
											<a href="#"><img src="https://via.placeholder.com/357x188" alt="image"></a>
										</div>
										<div class="blog_info">
											<div class="post_date"><a href="#">sep 10, 2019</a></div>
											<h5><a href="#">Vaishno Devi at night</a></h5>
											<p>You need to be sure there isn't anything embarrassing hidden in the middle of text.
												All the Lorem Ipsum generators on the Internet tend to repeat predefined</p>
											<a href="#" class="btn">Read More <i class="fa fa-caret-right"></i> </a>
										</div>
									</div>
								</article>
							</div>

						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!-- Latest-Blog -->

	<!-- About -->
	<section class="about_intro section-padding">
		<div class="container">
			<div class="about_us">
				<div class="section-header text-center">
					<h2>some important life lessons from bhagwat <u>gita</u></h2>
				</div>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
					book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
				<p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
			</div>
			<div class="text-center">
				<!-- Features -->
				<div class="features">
					<div class="row">
						<div class="col-lg-4 col-md-6">
							<div class="features_wrap features-after-none">
								<div class="f-f-icon"><img src="https://via.placeholder.com/64" alt=""></div>
								<h5 class="text-custom-secondary">area Of peace</h5>
								<p class="mb-0">Uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident.</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="features_wrap features-after-none">
								<div class="f-f-icon"><img src="https://via.placeholder.com/64" alt=""></div>
								<h5 class="text-custom-secondary">Community of devoters</h5>
								<p class="mb-0">Uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident.</p>
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="features_wrap features-after-none">
								<div class="f-f-icon"><img src="https://via.placeholder.com/64" alt=""></div>
								<h5 class="text-custom-secondary">preaching of Gita</h5>
								<p class="mb-0">Uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident.</p>
							</div>
						</div>
					</div>
				</div>
				<!-- /Features -->

			</div>
		</div>
	</section>
	<!-- /About -->

	<!-- Causes -->
	<section id="causes" class="section-padding gray_bg">
		<div class="container">
			<div class="owl-carousel">
				<div class="item">
					<div class="causes_info">
						<p class="subtitle">Gita's sermony</p>
						<h3 class="white_text">Five quotes of bhagwat gita</h3>
						<p class="white_text">A Karma-yogi performs action by body, mind, intellect, and senses, without attachment (or ego), only for self-purification."<p>
					</div>
				</div>
				<div class="item">
					<div class="causes_info">
						<p class="subtitle">krishna's preaching</p>
						<h3 class="white_text">Five quotes of mahabharat</h3>
						<p class="white_text">Meet this transient world with neither grasping nor fear,trust the unfolding of life,and you will attain true serenity.<p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- /Causes -->

	

	<!-- Donation-img section -->
	<section class="section-padding secondary-bg donation-img-section">
		<div class="container">
			<div class="row">
				<div class="col-md-6 align-self-center">
					<div class="section-header pb-0 m-0">
						<h2>Support Our Mission</h2>
					</div>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
						specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
					<div class="donation_form">
						<form>
							<div class="form-group">
								<div class="row">
									<div class="col-md-12 col-lg-12">
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text" id="basic-addon1">$</span>
											</div>
											<input type="text" class="form-control w-auto mb-0" value="$100">
										</div>
										<ul class="select_amount">
											<li class="mb-0">$10.00</li>
											<li class="mb-0">$25.00</li>
											<li class="mb-0">$50.00</li>
											<li class="mb-0 active">$100.00</li>
											<li class="mb-0">$500.00</li>
										</ul>
										<input type="submit" class="btn dark-btn" value="Donate Now">
									</div>
								</div>
							</div>

						</form>
					</div>
				</div>

				<div class="col-md-6 align-self-center img-width-100">
					<img src="https://via.placeholder.com/540x563" alt="img" class="img-fluid">
				</div>
			</div>
		</div>

	</section>
	<!-- /Donation-img section -->

	<!-- Testimonials -->
	<section class="our_testimonials section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-6 align-self-center">
					<img src="https://via.placeholder.com/480x580" alt="" class="img-fluid Mb_20">
				</div>
				<div class="col-md-6 align-self-center">
					<div class="about_company section-header pb-0 m-0">
						<h2>Our History</h2>

						<ul class="nav nav-tabs testi-nav-tabs">
							<li class="nav-item">
								<a class="nav-link active" data-toggle="tab" href="#home">1980</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" data-toggle="tab" href="#menu1">1990</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" data-toggle="tab" href="#menu2">2000</a>
							</li>

							<li class="nav-item">
								<a class="nav-link" data-toggle="tab" href="#menu3">2010</a>
							</li>
						</ul>

						<!-- Tab panes -->
						<div class="tab-content">
							<div id="home" class="container tab-pane active pl-0"><br>
								<h4>1980</h4>
								<p>Aliquam nec sem vulputate, sagittis felis id, semper nibh. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim
									veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip.</p>
								<a href="#" class="btn-link tk-btn-link"><u>Learn More <i class="fa fa-angle-right"></i></u></a>
							</div>
							<div id="menu1" class="container tab-pane fade pl-0"><br>
								<h4>1990</h4>
								<p>Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.
									Phasellus viverra nulla ut metus varius laoreet. Nam ornare pellentesque tortor.</p>
								<a href="#" class="btn-link tk-btn-link"><u>Learn More <i class="fa fa-angle-right"></i></u></a>
							</div>
							<div id="menu2" class="container tab-pane fade pl-0"><br>
								<h4>2000</h4>
								<p>Aliquam nec sem vulputate, sagittis felis id, semper nibh. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim
									veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip.</p>
								<a href="#" class="btn-link tk-btn-link"><u>Learn More <i class="fa fa-angle-right"></i></u></a>
							</div>
							<div id="menu3" class="container tab-pane fade pl-0"><br>
								<h4>2010</h4>
								<p>Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.
									Phasellus viverra nulla ut metus varius laoreet. Nam ornare pellentesque tortor.</p>
								<a href="#" class="btn-link tk-btn-link"><u>Learn More <i class="fa fa-angle-right"></i></u></a>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>
	</section>
	<!-- /Testimonials -->

	<!-- Call to Action -->
	<section class="section-padding call-action-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="call-content mx-auto text-center event-content">
						<p class="subtitle">Upcoming Event</p>
						<h3 class="text-white">Festivals Of Color Holi 2020</h3>
						<p class="text-white">Meet this transient world with neither grasping nor fear,trust the unfolding of life,and you will attain true serenity.</p>
					</div>
					<div class="timer event-timer">
						<div id="countdown"></div>
						<a href="#" class="btn btn-lg dark-btn margin-top-20">Register Now</a>
					</div>
				</div>

			</div>
		</div>

	</section>
	<!-- /Call to Action -->

<?php include "footer.php"?>
