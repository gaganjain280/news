<?php 

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

?>

<!DOCTYPE HTML>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<title>Akhil Bhartiya Asati Mahasabha New</title>
	<link rel="icon" href="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" type="image/x-icon">
	<!--Bootstrap -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" type="text/css">
	<!--OWL Carousel slider-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.css" type="text/css">
	<!--Custome Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" type="text/css">
	<!--Responsive Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css" type="text/css">
	<!--magnific Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/magnific-popup.css" type="text/css">
	<!--FontAwesome Font Style -->
	<link href="<?php echo base_url();?>assets/css/font-awesome.css" rel="stylesheet">
	<!-- Fav and touch icons -->

	<link rel="shortcut icon" href="favicon.png">
	<!-- Google-Font-->
	<link href="https://fonts.googleapis.com/css?family=Marcellus&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,400i,700,700i&display=swap" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.desk-menu{
    background-color: #DB4343;
    padding: 7px;
    padding-top: 12px;
    padding-right: 15px;
}
</style>
</head>


<body id="tl">
	<!-- Header -->
	<header id="header" class="nav-stacked" data-spy="affix" data-offset-top="1">
		<!-- Header-top -->
		<div class="header_top">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-6 p-0">
						<div class="follow_us" style="width:110px;">
							<ul>
								<li class="list-inline-item reg-button" style="display:block" ><a style="background-color: #45243C;" class="btn btn-sm dark-btn tilak-top-btn" href="login">Login</a></li>

							</ul>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-6 p-0">
						<ul class="top-btn list-inline">
							<!-- <li class="list-inline-item"><i class="fa fa-phone"></i><a href="#">+91 92292 21197</a></li> -->
							<!-- <li class="list-inline-item"><i class="fa fa-envelope"></i><a href="#">contact@asatisamaj.com</a></li> -->
							<li class="list-inline-item reg-button" style="display:block" ><a class="btn btn-sm dark-btn tilak-top-btn" href="register">Register</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- /Header-top -->

		<!-- Navigation -->
		<nav id="navigation_bar" class="navbar navbar-default">
			<div class="container desk-menu">
				<div class="navbar-header">
					<div class="logo">
						<a href="<?php echo base_url();?>">
							<img style="height:50px;border-radius:50%;margin-top:-10px;" src="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" class="img-circle" width="40" height="40">
							<span class="text-white" style="font-size:1em;font-weight:600;">&nbsp;Akhil Bhartiya Asati Mahasabha</span>
						</a>
					</div> <!-- /Logo -->
					<div id="menu_slide">
						<div id="nav-toggle-label">
							<div id="hamburger">
								<span></span>
								<span></span>
								<span></span>
							</div>
							<div id="cross">
								<span></span>
								<span></span>
							</div>
						</div>
					</div>
				</div>
				<div class="collapse navbar-collapse" id="navigation">
					<ul class="nav navbar-nav">
						
						<li class="dropdown"><a href="events.html">About Us<span class="nav_arrow"></span></a>
							<ul class="sub-menu">
								<li><a href="events.html">About Samaj</a></li>
								<li><a href="event-detail.html">Mahasabha History</a></li>
								<li><a href="event-detail.html">Our Social Workers</a></li>
								<li><a href="event-detail.html">Samitee Members</a></li>
							</ul>
						</li>
						<li><a href="contact-us.html">Matrimony</a></li>
						<li class="dropdown"><a href="events.html">Activities <span class="nav_arrow"></span></a>
							<ul class="sub-menu">
								<li><a href="events.html">Current Events</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="#">Books <span class="nav_arrow"></span></a>
							<ul class="sub-menu">
								<li><a href="shop-full-width.html">Books</a></li>
								<li><a href="shop-left.html">Periodicals</a></li>
								<li><a href="shop-right.html">Constitution</a></li>
							</ul>
						</li>
						<li><a href="contact-us.html">Festivals</a></li>
						<li><a href="contact-us.html">Contact</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- Navigation end -->
		
		<!-- Mobile Navigation -->
		<div class="mobile-menu">
			<ul class="wd-menu pop-scroll">
				<li><a href="contact-us.html">Login</a></li>
				<li class="has-child">
					<a href="#">About Us</a>
					<ul class="sub-menu">
						<li><a href="events.html">About Samaj</a></li>
						<li><a href="event-detail.html">Mahasabha History</a></li>
						<li><a href="event-detail.html">Our Social Workers</a></li>
						<li><a href="event-detail.html">Samitee Members</a></li>
					</ul>
				</li>
				<li><a href="contact-us.html">Matrimony</a></li>
				<li class="has-child">
					<a href="#">Activities</a>
					<ul class="sub-menu">
						<li><a href="events.html">Current Events</a></li>
					</ul>
				</li>
				<li class="has-child"><a href="#">Books</a>
					<ul class="sub-menu">
						<li><a href="shop-full-width.html">Books</a></li>
						<li><a href="shop-left.html">Periodicals</a></li>
						<li><a href="shop-right.html">Constitution</a></li>
					</ul>
				</li>
				<li><a href="contact-us.html">Festivals</a></li>
				<li><a href="contact-us.html">Contact</a></li>
			</ul>
		</div>
		<!-- END/Mobile Navigation -->
	</header>
	<!-- /Header -->
