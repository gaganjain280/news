<!DOCTYPE HTML>
<html lang="en">

<head>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<title>Akhil Bhartiya Asati Mahasabha</title>
	<link rel="icon" href="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" type="image/x-icon">

	<!--Bootstrap -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" type="text/css">
	<!--OWL Carousel slider-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.css" type="text/css">
	<!--Custome Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" type="text/css">
	<!--Responsive Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css" type="text/css">
	<!--magnific Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/magnific-popup.css" type="text/css">
	<!--FontAwesome Font Style -->
	<link href="<?php echo base_url();?>assets/css/font-awesome.css" rel="stylesheet">
	<!-- Fav and touch icons -->

	<link rel="shortcut icon" href="favicon.png">
	<!-- Google-Font-->
	<link href="https://fonts.googleapis.com/css?family=Marcellus&display=swap" rel="stylesheet">

	<link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,400i,700,700i&display=swap" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.register-form-t input{
	/* border: 0 none; */
	border: 1.5px solid #45243C;
}
.register-form-t select{
	/* border: 0 none; */
	border: 1.5px solid #45243C;
}
</style>
</head>

<body id="tl">
	<header class="tl-header tl-tilak-nav">
		<div class="container">
			<div class="tl-wrpr-inner">
				<div class="tl-center tl-logo py-4 mx-auto">
					<center>
						<a href="<?php echo base_url();?>">
							<img style="height:50px;border-radius:50%;margin-top:-10px;"
								src="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" class="img-circle"
								width="40" height="40">
						</a>
					</center>
				</div>
			</div>
			<div>
				<center><span style="color:#fff;font-size:1.5em">
						<a href="<?php echo base_url();?>" style="color:#fff">Akhil Bhartiya Asati Mahasabha</a><br>
					</span></center>
			</div>
		</div>
	</header>

	<!-- Inner-Intro -->
	<!-- Header/Banner -->
	<div class="container">
		<div class="row no-gutter">
			<div class="col-md-12">
				<div class="login py-5">
					<div class="row">
						<div class="col-md-6 offset-col-6 mx-auto d-block login-page">
							<div class="login-page">
								<h6 class="title" style="text-align: center;color:#DB4343">- Register & Create Family / सदस्य पंजीकृत करें और परिवार बनाएँ -</h6>
							</div><br>
							<form class="register-form-t" action="<?php echo base_url();?>auth/signup" method="post">
								<label for="salutation">Salutation / अभिवादन</label>
								<select class="form-control" name="salutation" id="salutation">
									<option value="" disabled="">Select Title</option>
									<option value="Shri">Shri</option>
									<option value="Smt">Smt</option>
									<option value="Other">Other</option>
									<option value="CA">CA</option>
								</select>
								<div class="row">
									<div class="col-md-4">
										<div class="form-label-group">
											<label for="fname">First Name / प्रथम नाम</label>
											<input type="text" id="fname" name="fname" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-label-group">
											<label for="mname">Middle Name / मध्य नाम</label>
											<input type="text" id="mname" name="mname" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-label-group">
											<label for="lname">Last Name / सरनेम</label>
											<input type="text" id="lname"  name="lname"class="form-control" placeholder="">
										</div>
									</div>
								</div>
									<label for="gender">Gender / लिंग</label>
									<select class="form-control" name="gender" id="gender">
										<option value="" disabled="">Select Title</option>
										<option value="male">Male</option>
										<option value="female">Female</option>
									</select>

								<div class="row">
									<div class="col-md-6">
										<div class="form-label-group">
											<label for="dob">Date of birth / जन्म दिन</label>
											<input type="date" id="dob"  name="dob" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-label-group">
											<label for="father">Father Name / पिता का नाम</label>
											<input type="text" id="father" name="father"  class="form-control" placeholder="">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-label-group">
											<label for="email">Email Address / ईमेल पता</label>
											<input type="email" id="email" name="email" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-label-group">
											<label for="mobile">Mobile Number / मोबाइल नंबर</label>
											<input type="number" id="mobile" name="mobile" class="form-control" placeholder="">
										</div>
									</div>
								</div>
								<label for="inputEmail">Kshetra / क्षेत्र</label>
								<select class="form-control" id="kshetra" name="kshetra">
									<option value="0">Select Kshetra / क्षेत्र का चयन करें</option>
									<option value="1">Malhera</option>
									<option value="1">Balaghat</option>
									<option value="1">Bhopal</option>
									<option value="1">Pune</option>
									<option value="1">India</option>
									<option value="1">Banda</option>
									<option value="1">Tikamgarh</option>
								</select>
								<div class="row">
									<div class="col-md-6">
										<div class="form-label-group">
											<label for="password">Password / पासवर्ड</label>
											<input type="text" id="password" name="password" class="form-control" placeholder="">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-label-group">
											<label for="inputEmail">Confirm Password / अनुरूप पासवर्ड</label>
											<input type="text" id="cpassword"  name="cpassword" class="form-control" placeholder="">
										</div>
									</div>
								</div><br>
								<div class="login-page">
									<h6 class="title">OTP Verification / ओ टी पी सत्यापन</h6>
								</div><br>
								<label>Send OTP बटन दबने पर असाटी महासभा के द्वारा आपके उपरोक्त मोबाइल पर  OTP का SMS भेजा जायेगा, अगले चरण हेतु SMS मे प्राप्त OTP को नीचे खण्ड मे अंकित करना अनिवार्य है।</label><br>
								<br>
								<div class="row">
									<div class="col-md-12">
										<div class="form-label-group">
									<span id="sendOtp" class="sendOtp btn btn-sm btn-block tl-btn-round-2 text-uppercase font-weight-bold mb-2"
									type="" style="background: white; color: #CA4042;border: 2px solid #CA4042;">Send OTP / ओटीपी जनरेट करें</span>

										</div>
									</div>
									<div class="col-md-12">
										<div class="form-label-group">
											<label for="otp">OTP / ओ टी पी</label>
											<input type="text" id="otp" class="form-control"  placeholder="Please type OTP here" required>
										</div>
									</div>
									<div class="col-md-12" id="otp_result"></div>
								</div><br>
								<div class="custom-control custom-checkbox mb-3">
									<input type="checkbox" class="custom-control-input" id="customCheck1">
									<label class="custom-control-label" for="customCheck1">I Agree With <a href="#">Terms &amp; Conditions / मैं नियम और शर्तों से सहमत हूं</a></label>
								</div>

								
								<button class="btn btn-lg btn-block tl-btn-round-2 text-uppercase font-weight-bold mb-2"
									type="submit">Register / रजिस्टर करें</button>

							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


</body>

</html>
<script type='text/javascript'>
   $(document).ready(function(){
   	$("#sendOtp").click(function()
    {
     var mob=$('#mobile').val();
      if(mob.length=='10'){
       $.ajax({
                url:'FrontendController/sendOtp',
                method: 'post',
                data: {mobile: mob},
                success: function(response){
                	alert("your otp is sent on your register mobile no!");
                }
             });
      }
   });

	$("#otp").change(function()
    {
     var mob=$('#mobile').val();
     var otp=$('#otp').val();
      if(otp!==''){
    	 $('#otp_result').empty();
       $.ajax({
                url:'FrontendController/OtpVarification',
                method: 'post',
                data: {otp : otp,
                       mob : mob},
                success: function(response){
                	if(response!=='Varified'){
                	$('#otp').val('');
                	}
                	$("#otp_result").append(response);
                	alert(response);
                   // alert(response);                           
                }
             });
      }
    });



  });

 </script>