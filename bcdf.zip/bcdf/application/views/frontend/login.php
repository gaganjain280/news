<!DOCTYPE HTML>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
	<title>Akhil Bhartiya Asati Mahasabha</title>
	<link rel="icon" href="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" type="image/x-icon">

	<!--Bootstrap -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" type="text/css">
	<!--OWL Carousel slider-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.css" type="text/css">
	<!--Custome Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css" type="text/css">
	<!--Responsive Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css" type="text/css">
	<!--magnific Style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/magnific-popup.css" type="text/css">
	<!--FontAwesome Font Style -->
	<link href="<?php echo base_url();?>assets/css/font-awesome.css" rel="stylesheet">
	<!-- Fav and touch icons -->

	<link rel="shortcut icon" href="favicon.png">
	<!-- Google-Font-->
	<link href="https://fonts.googleapis.com/css?family=Marcellus&display=swap" rel="stylesheet">

	<link href="https://fonts.googleapis.com/css?family=Noto+Sans:400,400i,700,700i&display=swap" rel="stylesheet">
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.login-form-t input{
	border: 1.5px solid #45243C;
}
</style>
</head>

<body id="tl">
	<header class="tl-header tl-tilak-nav">
		<div class="container">
			<div class="tl-wrpr-inner">
				<div class="tl-center tl-logo py-4 mx-auto">
					<center>
						<a href="<?php echo base_url();?>">
							<img style="height:50px;border-radius:50%;margin-top:-10px;"
								src="<?php echo base_url();?>assets/images/asatisamaj-logo.jpg" class="img-circle"
								width="40" height="40">
						</a>
					</center>
				</div>
			</div>
			<div>
				<center><span style="color:#fff;font-size:1.5em">
					<a href="<?php echo base_url();?>" style="color:#fff">Akhil Bhartiya Asati Mahasabha</a><br>
				</span></center>
			</div>
		</div>
	</header>

	<!-- Inner-Intro -->
	<!-- Header/Banner -->
	<div class="container">
		<div class="row no-gutter">
			<div class="col-md-12">
				<div class="login py-5">
					<div class="row">
						<div class="col-md-6 offset-col-6 mx-auto d-block login-page">
							<div class="login-page">
								<?php if($this->session->flashdata('msg')) :?>
								<div class="alert alert-danger" role="alert">
									<?php echo $this->session->flashdata('msg'); ?>
								</div>
								<?php endif; ?>
								<h4 class="title">Login</h4>
							</div>
							<form class="login-form-t" action="<?php echo base_url();?>/auth/login" method="post">
								<div class="form-label-group">
									<label for="inputEmail">ID</label>
									<input type="text" id="emailid" name="emailid" class="form-control" placeholder="AST-XXXXXXX or XXXXXXX">
								</div>
								<div class="form-label-group">
									<label for="inputPassword">Password</label>
									<input type="password" id="password" name="password" class="form-control"
										placeholder="Your Secret Password" >
								</div>
								<button class="btn btn-lg btn-block tl-btn-round-2 text-uppercase font-weight-bold mb-2"
									type="submit">Sign in</button>

								<div class="text-center">
									<a class="small" href="#">Forgot password?</a>
								</div>
								<hr>
								<div class="text-center" style="border:2px  solid #45243C">
									<a class="small" href="register">NEW USER ? REGISTER FAMILY HERE</a>
								</div>

							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


</body>

</html>
