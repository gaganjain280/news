<?php
class Publish extends CI_Model { 

    public function newsInsertDetails($context,$description,$kshetra,$image_path,$image_name,$source,$apply)
    {
        $date  =date('Y-m-d H:i:s');

        $data  = array(
                    'context' => $context,
                    'description' => $description,
                    'kshetra' => $kshetra,
                    'creator_id' => 'AST-1',
                    'image_name' => $image_name,
                    'source' => $source,
                    'image_path' => $image_path,
                    'created_at'=>$date,
                    'updated_at'=>$date,
                    'status'=>$apply,
                );

        $result = $this->db->insert('news', $data);
        if($result){
            return "<p class='bg-success text-white text-center'>News Added Successfully!</p>";
        }else{
            return $result;
        }
           
    }
    public function newsUpdateDetails($id, $context, $description,$kshetra,$image_path,$image_name,$source,$apply)
    {
        $date  =date('Y-m-d H:i:s');
        $this->db->set('context', $context);
        $this->db->set('description', $description);
        $this->db->set('creator_id', 'AST-1');
        $this->db->set('source', $source);
        $this->db->set('kshetra', $kshetra);
        $this->db->set('updated_at', $date);
        $this->db->set('status', $apply);
        if($image_path!=="" && $image_name!==""){
          $this->db->set('image_path', $image_path);
          $this->db->set('image_name', $image_name);
        }
        $this->db->where('id', (int)$id);
        $result= $this->db->update('news'); 
        if($result){
            return "<p class='bg-success text-white text-center'>News Updated Successfully!</p>";
        }else{
            return $result;
        }
           
    }
    public function eventInsertDetails($event)
    {
        $date  =date('Y-m-d H:i:s');
        $data  = array(
                    'context'     =>  $event['context'],
                    'description' => $event['description'],
                    'kshetra'     => $event['kshetra'],
                    'creator_id'  => 'AST-1',
                    'start_event_date' => $event['eventStartDate'],
                    'sponsor'    => $event['sponsor'],
                    'organiser'  => $event['organiser'],
                    'end_event_date' => $event['eventEndDate'],
                    'image_name' => $event['image_name'],
                    'created_at' =>$date,
                    'updated_at' =>$date,
                    'status'     =>$event['apply']
                );
        $result = $this->db->insert('events', $data);
        if($result){
            return "<p class='bg-success text-white text-center'>Event Added Successfully!</p>";
        }else{
            return $result;
        }
           
    }
}
