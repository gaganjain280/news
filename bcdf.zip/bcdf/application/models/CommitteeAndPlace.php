<?php
class CommitteeAndPlace extends CI_Model { 

    public function cityInsertDetails($city)
    {
      $date  =date('Y-m-d H:i:s');
        $cityData  = array(
                    'kshetra_id' =>$city['kshetras'],
                    'nagar_sort_code' => $city['code'],
                    'created_by' => 'AST-1',
                    'nagar' => $city['name'],
                    'created_at'=>$date,
                );
         $result = $this->db->insert('nagar', $cityData);
        if($result){
         $insert_id = $this->db->insert_id();
         $committeeData  = array(
                    'name' =>$city['CommitteeName'],
                    'type' => '3',
                    'kshetra_id' => '0',
                    'nagar_id' => $insert_id,
                    'created_at' => $date,
                    'created_by' => 'AST-1',
                    // 'status'=>$kshetra['apply'],
                );
        $cresult = $this->db->insert('committee', $committeeData);
          if(!$cresult){
           return $cresult;
          } 
         return "<p class='bg-success text-white text-center'>City & Committee Added Successfully!</p>";
        }else{
            return $result;
        }
    }
    public function cityUpdateDetails($city,$id)
    {
        $date  =date('Y-m-d H:i:s');
        $this->db->set('kshetra_id', $city['kshetras']);
        $this->db->set('nagar_sort_code', $city['code']);
        $this->db->set('created_by', 'AST-1');
        $this->db->set('nagar',$city['name']);
        $this->db->set('updated_at', $date);
        $this->db->where('id', (int)$id);
        $result= $this->db->update('nagar'); 
        if($result){
         $this->db->set('name', $city['CommitteeName']);
         $this->db->set('type', '3');
         $this->db->set('created_by','AST-1');
         $this->db->set('updated_at',$date);
         $this->db->where('nagar_id', (int)$id);
         $cresult= $this->db->update('committee'); 
          if(!$cresult){
           return $cresult;
          } 
         return "<p class='bg-success text-white text-center'>City & Committee Updated Successfully!</p>";
        }else{
            return $result;
        }
    }
    public function kshetraInsertDetails($kshetra)
    {
        $date  =date('Y-m-d H:i:s');
        $KshetraData  = array(
                    'kshetra_name' =>$kshetra['k_name'],
                    'kshetra_sort_code' => $kshetra['code'],
                    'created_by' => 'AST-1',
                    'pincode' => $kshetra['pincode'],
                    'state' => $kshetra['state'],
                    'district' => $kshetra['district'],
                    'created_at'=>$date,
                );
         $result = $this->db->insert('kshetra', $KshetraData);
        if($result){
         $insert_id = $this->db->insert_id();
         $committeeData  = array(
                    'name' =>$kshetra['committee_name'],
                    'type' => '2',
                    'kshetra_id' => $insert_id,
                    'nagar_id' => '0',
                    'created_at' => $date,
                    'created_by' => 'AST-1',
                    
                    // 'status'=>$kshetra['apply'],
                );
        $cresult = $this->db->insert('committee', $committeeData);
          if(!$cresult){
           return $cresult;
          } 
         return "<p class='bg-success text-white text-center'>Kshetra & Committee Added Successfully!</p>";
        }else{
            return $result;
        }
    }
    public function kshetraUpdateDetails($kshetra,$id)
    {

        $date  =date('Y-m-d H:i:s');
        $this->db->set('kshetra_name', $kshetra['k_name']);
        $this->db->set('kshetra_sort_code', $kshetra['code']);
        $this->db->set('created_by', 'AST-1');
        $this->db->set('pincode',$kshetra['pincode']);
        $this->db->set('state', $kshetra['state']);
        $this->db->set('updated_at', $date);
        $this->db->set('district',$kshetra['district']);
        $this->db->where('id', (int)$id);
        $result= $this->db->update('kshetra'); 
        if($result){
         $this->db->set('name', $kshetra['committee_name']);
         $this->db->set('created_by', 'AST-1');
         $this->db->set('updated_at',$date);
         $this->db->where('kshetra_id', (int)$id);
         $cresult= $this->db->update('committee'); 
          if(!$cresult){
           return $cresult;
          } 
         return "<p class='bg-success text-white text-center'>Kshetra & Committee Update Successfully!</p>";
        }else{
            return $result;
        }
    }
  
}
