<?php
class Family extends CI_Model {

	public function family_list( $limit, $offset )
	{

		$query = $this->db->select('family.*,kshetra.kshetra_name,nagar.nagar')
				->from('family')
				->join('kshetra', 'kshetra.id = family.kshetra_id')
				->join('nagar', 'nagar.id = family.nagar_id')
				->limit( $limit, $offset )
		 		->get();
		// echo "<pre>";
		// print_r($query->row());
							
		return $query->result();
	}

	public function num_rows()
	{
		$user_id = $this->session->userdata('user_id');
		$query = $this->db
				->from('family')
				->join('kshetra', 'kshetra.id = family.kshetra_id')
				->join('nagar', 'nagar.id = family.nagar_id')
		 		->get();
		 return $query->num_rows();
	}


	public function family_details( $id )
	{

		$query = $this->db->select('family.*,kshetra.kshetra_name,nagar.nagar, user_address.house_no, user_address.house_name, user_address.colony, user_address.area, user_address.country, user_address.state, user_address.city, user_address.pincode, user_profile.user_id, user_profile.family_id, user_profile.file_name, user_profile.file_type, user_profile.file_path, user_profile.file_ext, user_profile.profile_type')
				->from('family')
				->join('kshetra', 'kshetra.id = family.kshetra_id')
				->join('nagar', 'nagar.id = family.nagar_id')
				->join('user_address', 'user_address.family_id = family.id')
				->join('user_profile', 'user_profile.family_id = family.id')
				->where('family.id', $id)
		 		->get();
		// echo "<pre>";
		// print_r($query->row());
							
		return $query->result();
	}


	public function family_members( $id )
	{

		$query = $this->db->select('family.*,kshetra.kshetra_name,nagar.nagar, user_address.house_no, user_address.house_name, user_address.colony, user_address.area, user_address.country, user_address.state, user_address.city, user_address.pincode, user_profile.user_id, user_profile.family_id, user_profile.file_name, user_profile.file_type, user_profile.file_path, user_profile.file_ext, user_profile.profile_type')
				->from('family')
				->join('kshetra', 'kshetra.id = family.kshetra_id')
				->join('nagar', 'nagar.id = family.nagar_id')
				->join('user_address', 'user_address.family_id = family.id')
				->join('user_profile', 'user_profile.family_id = family.id')
				->where('family.id', $id)
		 		->get();
		
							
		return $query->result();
	}
	
}

