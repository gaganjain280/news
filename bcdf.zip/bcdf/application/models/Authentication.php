<?php

class Authentication extends CI_Model {



	public function check_login( $username, $password )
	{	

	    $condition = '(asati_id="'.$username.'" OR mobile="'.$username.'") AND password ="'.$password.'"';

	    $this->db->select('id,asati_id,email,mobile,,login_status,role_id,created_at,updated_at')
				->from('user')
				->where($condition);
		$query = $this->db->get();

		if ( $query->num_rows() ) {
			return $query->row();
		} else {
			return FALSE;
		}
	}
}


 		
