<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class FamiliyController extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('family');
       
	}
	
	public function index() {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}

        $data["headTitle"] = "Families";
		$this->load->view('backend/familyAdd',$data);
	}


	public function list($status) {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}

		if ($status == 1) {
			$data["listType"] = "All Activeted Families";
		} else {
			$data["listType"] = "All De-Activeted Families";
		}

		$this->load->library('pagination');

		$config = [
			'base_url'			=>	base_url('/family/list/1'),
			'per_page'			=>	10,
			'total_rows'		=>	$this->family->num_rows(),
			'full_tag_open'		=>	"<ul class='pagination pagination-sm m-0 float-right'>",
			'full_tag_close'	=>	"</ul>",
			'first_tag_open'	=>	'<li class="page-item">',
			'first_tag_close'	=>	'</li>',
			'last_tag_open'		=>	'<li class="page-item">',
			'last_tag_close'	=>	'</li>',
			'next_tag_open'		=>	'<li class="page-item">',
			'next_tag_close'	=>	'</li>',
			'prev_tag_open'		=>	'<li class="page-item">',
			'prev_tag_close'	=>	'</li>',
			'num_tag_open'		=>	'<li class="page-item">',
			'num_tag_close'		=>	'</li>',
			'cur_tag_open'		=>	"<li class='active page-item'><a>",
			'cur_tag_close'		=>	'</a></li>',
		];

		

		$this->pagination->initialize($config);


		$family = $this->family->family_list( $config['per_page'], $this->uri->segment(4));
		$data["family"] = $family;
		$data["headTitle"] = "Families";

        $this->load->view('backend/familyList', $data);
	}

	public function view($id) {

		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}

		$family = $this->family->family_details($id);
		$familyMembers = $this->family->family_members($id);

		$data["family"] = $familyMembers[0];
		$data["familyMembers"] = $family[0];

		$data["headTitle"] = "Families";
		$this->load->view('backend/familyDetails',$data);
	}

	public function insert() {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}


			$inputData = $input = $this->input->post();
			// 	echo "<pre>";
			// 	print_r($_FILES);
			// 	print_r($inputData);
			// exit;

			/* User Data */
			$asati_id_guid = "M-".rand(); 
	        $insert_user['asati_id'] =  $asati_id_guid; 
			$insert_user['email'] = $inputData['email']; 
			$insert_user['mobile'] = $inputData['mobile']; ; 
			$insert_user['password'] =  sha1($inputData['password']); 
			$insert_user['login_status'] = 1; 
			$insert_user['role_id'] = 2; 
			$insert_user['created_at'] = date("Y-m-d H:i:s"); 

			/* Family Data */
			$insert_family['f_name'] = $inputData['lastName'];
			$insert_family['f_creator_id'] = $this->session->userdata('user_id');
			$insert_family["f_indigeneous"] = $inputData['indigenous'];
			$insert_family["f_gotra"] = $inputData['gotra'];
			$insert_family["f_dynasty"] = $inputData['dynasty'];
			$insert_family["kshetra_id"] = $inputData['kshetra'];
			$insert_family["nagar_id"] = $inputData['nagar'];

			/** Family Address */
			$insert_address['house_no'] = $inputData["house_no"];
			$insert_address['house_name'] = $inputData["house_name"];
			$insert_address['colony'] = $inputData["colony"];
			$insert_address['area'] = $inputData["area"];
			$insert_address['country'] = $inputData["country"];
			$insert_address['state'] = $inputData["state"];
			$insert_address['city'] = $inputData["city"];
			$insert_address['pincode'] = $inputData["pincode"];
			$insert_address['address_type'] = "family";
			
			/** Member Detail Data */
			$insert_member['salutation'] = $inputData['salutation'];
			$insert_member['f_name'] = $inputData['firstName'];
			$insert_member['m_name'] = $inputData['middleName'];
			$insert_member['l_name'] = $inputData['lastName'];
			$insert_member['is_head'] = 1;


			// $this->db->trans_begin();			

			if($this->db->insert('user', $insert_user)){
				$user_id = $this->db->insert_id();

				if (isset($_FILES['memberImg'])) {
					$_FILES['file']['name'] = $_FILES['memberImg']['name'];
					$_FILES['file']['type'] = $_FILES['memberImg']['type'];
					$_FILES['file']['tmp_name'] = $_FILES['memberImg']['tmp_name'];
					$_FILES['file']['error'] = $_FILES['memberImg']['error'];
					$_FILES['file']['size'] = $_FILES['memberImg']['size'];

					$uploadPath = 'assets/uploads/member'	;
					$config['upload_path'] = $uploadPath;
					$config['allowed_types'] = 'jpg|jpeg|png|gif';

					$this->load->library('upload', $config);
					$this->upload->initialize($config);

					if ($this->upload->do_upload('file')) {
						$fileData = $this->upload->data();
						$ImageData['file_name'] = $fileData['file_name'];
						$ImageData['file_type'] = $fileData['file_type'];
						$ImageData['file_path'] = $fileData['file_path'];
						$ImageData['file_ext'] = $fileData['file_ext'];
						$ImageData['profile_type'] = "user";
						$ImageData['created_at'] = date("Y-m-d H:i:s");
						$ImageData['user_id'] = $user_id;
						$this->db->insert('user_profile', $ImageData);
					}
				}


				$famid_guid =  "F-".rand();
				$insert_family['f_asati_id'] =  $famid_guid;
				$insert_family['f_head_id'] = $user_id;
				
				if($this->db->insert('family', $insert_family)){
					$family_id = $this->db->insert_id();
				
					if (isset($_FILES['familyImg'])) {
						$_FILES['file']['name'] = $_FILES['familyImg']['name'];
						$_FILES['file']['type'] = $_FILES['familyImg']['type'];
						$_FILES['file']['tmp_name'] = $_FILES['familyImg']['tmp_name'];
						$_FILES['file']['error'] = $_FILES['familyImg']['error'];
						$_FILES['file']['size'] = $_FILES['familyImg']['size'];
						
						$uploadPath = 'assets/uploads/family';
						$config['upload_path'] = $uploadPath;
						$config['allowed_types'] = 'jpg|jpeg|png|gif';

						$this->load->library('upload', $config);
						$this->upload->initialize($config);

						if ($this->upload->do_upload('file')) {
							$fileData = $this->upload->data();
							$ImageData['file_name'] = $fileData['file_name'];
							$ImageData['file_type'] = $fileData['file_type'];
							$ImageData['file_path'] = $fileData['file_path'];
							$ImageData['file_ext'] = $fileData['file_ext'];
							$ImageData['profile_type'] = "family";
							$ImageData['created_at'] = date("Y-m-d H:i:s");
							$ImageData['family_id'] = $family_id;
							$this->db->insert('user_profile', $ImageData);
						}
					}

					$insert_address['family_id'] = $family_id;
					$this->db->insert('user_address', $insert_address);
					$insert_member['user_id'] = $user_id;
					$insert_member['family_id'] = $family_id;
					
					if($this->db->insert('family_member', $insert_member)){
						$this->session->set_flashdata('msg','You have Registered Successfully Your family Id is'.$famid_guid.' & Your member Id '.$asati_id_guid.' is  Please Login with your member Id.'); 
						redirect(base_url() . 'family', 'refresh');
					}

					// if ($this->db->trans_status() === FALSE){
					// 	$this->db->trans_rollback();
					// }else{
					// 	$this->db->trans_commit();
					// }
				}
			}



        // $this->load->view('backend/dashboard');
	}

	public function update() {
        if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}

		try {
				// $this->load->view('backend/dashboard');
			$inputData = $input = $this->input->post();

			$famdata['f_name'] = $inputData['familyName'];
			$famdata['kshetra_id'] = $inputData['kshetra'];
			$famdata['nagar_id'] = $inputData['nagar'];
			$famdata['f_indigeneous'] = $inputData['Indigenous'];
			$famdata['f_dynasty'] = $inputData['Gotra'];
			$famdata['f_dynasty'] = $inputData['Dynasty'];
	
			$this->db->where('id', $inputData['family_id']);
			$result = $this->db->update('family', $famdata);


			$addr['house_no'] = $inputData['house_no'];
			$addr['house_name'] = $inputData['house_name'];
			$addr['colony'] = $inputData['colony'];
			$addr['pincode'] = $inputData['pincode'];
			$addr['area'] = $inputData['area'];
			$addr['city'] = $inputData['city'];
			$addr['state'] = $inputData['state'];
			$addr['country'] = $inputData['country'];

			$this->db->where('family_id', $inputData['family_id']);
			$this->db->where('address_type','family');
    		$this->db->update('user_address', $addr);

                if($result == TRUE){
						$this->session->set_flashdata('feedback',"Family Updated Successfully !!");
						$this->session->set_flashdata('feedback_class', 'alert-success');
						redirect(base_url() . 'family/view/18', 'refresh');
				}

		} catch (Exception $e) {
			
		}
	        				
	}

	public function delete() {
        if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}

        $this->load->view('backend/dashboard');
	}

	public function getNagar()
	{
		$id = $input = $this->input->post('id');
		$result = $this->db->get_where('nagar', array(
			'kshetra_id' => $id,
		))->result_array();
		
		echo json_encode($result);

	}
	
	public function getByPincode()
	{
		$str= $input = $this->input->post('str');
		$result = $this->db->select('*')
				 ->from('pincode_state')
				 ->where("pincode LIKE '$str%'")
				 ->limit(50)
				 ->get()->result_array();

		echo json_encode($result);

	
	}


}