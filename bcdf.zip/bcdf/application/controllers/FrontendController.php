<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class FrontendController extends CI_Controller {

	function __construct() {
        parent::__construct();

	}

	public function index() {
        $this->load->view('frontend/homepage');
	}

	public function loginPage()
	{
		$this->load->view('frontend/login');
	}

	public function registerPage()
	{
		$this->load->view('frontend/register');
	}
	public function sendOtp()
	{ 
		$mobile = $this->input->get('mobile');
	    $fourdigitrandom = rand(1000,9999);
	    $this->session->set_userdata('otpcode',$fourdigitrandom);
	    $this->session->set_userdata('mobile', $mobile);
	    $authKey = "300418AqyK2QHW5daffc0b";
		$mobileNumber = $mobile;
		//Sender ID,While using route4 sender id should be 6 characters long.
		$senderId = "ASATIS";
		//Your message to send, Add URL encoding here.
		$message = urlencode("Hello Member Your Otp is :".$fourdigitrandom);
		//Define route 
		$route = "route4";
		//Prepare you post parameters
		$postData = array(
		    'authkey' => $authKey,
		    'mobiles' => $mobileNumber,
		    'message' => $message,
		    'sender' => $senderId,
		    'route' => $route
		);
		//API URL
		$url="http://api.msg91.com/api/sendhttp.php";
		// init the resource
		$ch = curl_init();
		curl_setopt_array($ch, array(
		    CURLOPT_URL => $url,
		    CURLOPT_RETURNTRANSFER => true,
		    CURLOPT_POST => true,
		    CURLOPT_POSTFIELDS => $postData
		    //,CURLOPT_FOLLOWLOCATION => true
		));
		//Ignore SSL certificate verification
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		//get response
		$output = curl_exec($ch);
	    $this->session->set_userdata('otpcode_id',"output");
		//Print error if any
		if(curl_errno($ch))
		{
		    echo 'error:' . curl_error($ch);
		}
		curl_close($ch);
        echo $output;
	}
	public function OtpVarification()
	{
       $userOtp = $this->input->get('otp');
       $userMob = $this->input->get('mob');
       $session_otp=$this->session->userdata('otpcode');
       $session_mob=$this->session->userdata('mobile');
       if(($userOtp==$session_otp)&&($userMob==$session_mob)){
		echo "Varified";
       }else{
		echo "Invalid OTP!";
       }
	}
}