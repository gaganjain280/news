<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');



class DashboardController extends CI_Controller {

	function __construct() {
        parent::__construct();

	}

	public function index() {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}
		
		$data["headTitle"] = "Dashboard";
        $this->load->view('backend/dashboard',$data);
	}
}