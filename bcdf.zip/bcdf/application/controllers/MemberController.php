<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MemberController extends CI_Controller {

	function __construct() {
        parent::__construct();

	}

	
	public function index() {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}
        
        $data["headTitle"] = "Members";
        $this->load->view('backend/memberAdd',$data);
	}

	public function list($status) {

		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}

		if ($status == 1) {
			$data["listType"] = "All Activeted Members";
		} else {
			$data["listType"] = "All De-Activeted Members";
		}
		 
		$data["headTitle"] = "Members";
        $this->load->view('backend/membersList',$data);
	}

	public function view($id) {

		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}

		$data["headTitle"] = "Members";
        $this->load->view('backend/memberDetails',$data);
	}

	public function insert() {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}
        $data["headTitle"] = "Members";
        $this->load->view('backend/memberAdd',$data);
	}
	public function update() {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}
        $this->load->view('backend/dashboard');
	}
	public function delete() {
		if ($this->session->userdata('login') != 1){
		 	redirect(base_url() . 'login', 'refresh');
		}
        $this->load->view('backend/dashboard');
	}

}