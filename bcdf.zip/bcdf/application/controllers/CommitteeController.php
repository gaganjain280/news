<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class CommitteeController extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('CommitteeAndPlace','CAP');
        $this->load->database();
        $this->load->library('session');
	}
  public function index() {
        $this->load->view('backend/dashboard');
  }
// Commitee list
  //  City Related crud function
  public function getCommitteList()
   {
       // $condition = 'kshetra_id ="'.$kshetra_id.'"';
             // $query = $this->db->select('*')->from('committee')->
             // where($condition)->get()->result();
             $query = $this->db->select('*')->from('committee')->
             get()->result();
              $res= json_encode($query);
             print_r($res);
   }
  public function mahasabhaList($value='')
  {
    $data["headTitle"] = "Mahasabha";
    $data["listType"] = " Mahasabha List";
        $this->load->view('backend/mahasabhaList',$data);
  } 

	//  common functions
  public function numRows($table_name)
   {
	           $query = $this->db->select('*')->from($table_name)->get();
	           return $query->num_rows();
	 }  
  public function getTableData($table_name,$limit,$offset)
   {
        $query = $this->db->select('*')
                         ->from($table_name)
                         ->limit($limit,$offset)
                         ->get();
        return $query->result();
   }
// commitee Related crud function
  public function committeList($value='')
   { $this->load->helper('form');
    $data["headTitle"] = "Committee";
    $data["listType"] = " Committee List";
        $this->load->view('backend/committeList',$data);
   } 

// Kshetra Related crud function
  public function kshetraHandleError($value="")
   {
       redirect(base_url() . 'committee/Kshetra/0', 'refresh');
   }
  public function kshetraList($value)
   {
       $data["headTitle"] = "Kshetra and City";
       $data["listType"]  = "Kshetra List";
        $this->load->view('backend/kshetraList',$data);
   } 

    public function addKshetraForm($value='')
    {
       $data["headTitle"] = "Add Kshetra";
       $data["listType"]  = "Add Kshetra";
       $this->load->view('backend/addKshetraForm',$data);
    }
        public function updateKshetraForm($id)
    {
       $data["headTitle"] = "Update Kshetra";
       $data["listType"]  = "Update  Kshetra";
       $a=$this->db->select('k.*,c.name');
       $this->db->from('kshetra k');
       $this->db->join('committee c', 'c.kshetra_id = k.id AND k.id="'.$id.'"');
       $data["kshetraData"] = $a->get()->result();
       $data["id"] = $id;
       $this->load->view('backend/updateKshetraForm',$data);
    } 
    public function kshetraInsert($value='')
    {  
       $kshetra['k_name']       = $this->input->post('k_name');
       $kshetra['code']   = $this->input->post('code');
       $kshetra['committee_name']   =  $this->input->post('committee_name');
       $kshetra['pincode']       = $this->input->post('pincode');
       $kshetra['state']     = $this->input->post('state');
       $kshetra['district']     = $this->input->post('district');
       // $apply                  = $this->input->post('apply');
       // if($apply==""){
       //   $kshetra['apply']='0';
       // }else{
       //   $kshetra['apply']='1';
       // } 
       if($kshetra['k_name']==""||$kshetra['code']==""||$kshetra['committee_name']==""||$kshetra['pincode']==""||$kshetra['state']=="")
       {  
         $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Please Provide valid details!</p>");
       }else
       {          
         $result = $this->CAP->kshetraInsertDetails($kshetra);
          $this->session->set_flashdata("result",$result); 
       }   
      redirect(base_url() . 'kshetra/addKshetra', 'refresh');
   } 
     public function khshetraUpdateUpd($id)
    { 

       $kshetra['k_name']        = $this->input->post('k_name');
       $kshetra['code']          = $this->input->post('code');
       $kshetra['committee_name']=  $this->input->post('committee_name');
       $kshetra['pincode']       = $this->input->post('pincode');
       $kshetra['state']         = $this->input->post('state');
       $kshetra['district']      = $this->input->post('district');
       // $apply                    = $this->input->post('apply');
       // if($apply==""){ 
       //   $kshetra['apply']='0';
       // }else{
       //   $kshetra['apply']='1';
       // } 
       if($kshetra['k_name']==""||$kshetra['code']==""||$kshetra['committee_name']==""||$kshetra['pincode']==""||$kshetra['state']=="")
       {  
         $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Please Provide valid details!</p>");
       }else
       {          
         $result = $this->CAP->kshetraUpdateDetails($kshetra,$id);
          $this->session->set_flashdata("result",$result); 
          redirect(base_url() . '/khshetra/updateKshetraForm/'.$id);

       }   
   } 

    public function kshetarDataTableList()
    {
        $draw = intval($this->input->post("draw"));
        $start = intval($this->input->post("start"));
        $length = intval($this->input->post("length"));
        $order = $this->input->post("order");
        $search= $this->input->post("search");
        $search = $search['value'];
        $col = 0;
        $dir = "";
        if(!empty($order))
        {
            foreach($order as $o)
            {
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }

        if($dir != "asc" && $dir != "desc")
        {
            $dir = "desc";
        }
        $valid_columns = array(
            0=>'id',
            1=>'kshetra_name',
            2=>'pincode',
            3=>'state',
            4=>'created_at',
        );
        if(!isset($valid_columns[$col]))
        {
            $order = null;
        }
        else
        {
            $order = $valid_columns[$col];
        }
        if($order !=null)
        {
            $this->db->order_by($order, $dir);
        }
        
        if(!empty($search))
        {
            $x=0;
            foreach($valid_columns as $sterm)
            {
                if($x==0)
                {
                    $this->db->like($sterm,$search);
                }
                else
                {
                    $this->db->or_like($sterm,$search);
                }
                $x++;
            }                 
        }
        $this->db->limit($length,$start);
        $queryData = $this->db->get("kshetra");
        $data = array();
        foreach($queryData->result() as $rows)
        {
            $kshetra_url=base_url().'khshetra/updateKshetraForm/'.$rows->id;
            $city_list_url=base_url().'city/viewList/'.$rows->id;
 
            $data[]= array(
                $rows->id,
                $rows->kshetra_name,
                $rows->state,
                $rows->created_at,
                '<a href="'.$kshetra_url.'" class="btn btn-outline-info btn-sm"><i class="fas fa-edit nav-icon"></i></a>
                 <a href="'.$city_list_url.'" class="btn btn-outline-info btn-sm"><i
                          class="fas fa-list nav-icon"></i></a>'
            );     
        }
        $total_records = $this->totalListDataCount("kshetra");
        $output = array(
            "draw" => $draw,
            "recordsTotal" => $total_records,
            "recordsFiltered" => $total_records,
            "data" => $data
        );
        echo json_encode($output);
        exit();
    }
 
//  City Related crud function
  public function getcityAsti()
   {
       $kshetra_id       = $this->input->post('kshetra_id');
       $condition = 'kshetra_id ="'.$kshetra_id.'"';
             $query = $this->db->select('*')->from('nagar')->
             where($condition)->get()->result();
              $res= json_encode($query);
             print_r($res);
   }
	public function cityList($kshetra_id)
	 {
      $data["headTitle"] = "City List";
      $data["listType"]  = "City List";
      $this->session->set_userdata('kshetra_id',$kshetra_id);
      $data["kshetra_id"]  = $kshetra_id;
      $this->load->view('backend/cityList',$data);
	 } 
  public function addCityForm($value='')
    {
       $data["headTitle"] = "Add Nagar";
       $data["listType"]  = "Add Nagar";
       $data["kshetraList"]=  $this->db->select('id,kshetra_name')
                             ->from('kshetra')->get()->result();
       $this->load->view('backend/addCityForm',$data);
    }
  public function cityInsert($value=''){
       $city['kshetras']       = $this->input->post('kshetras');
       $city['code']   = $this->input->post('code');
       $city['CommitteeName']   = $this->input->post('CommitteeName');
       $city['name']   = $this->input->post('name');
       if($city['kshetras']==""||$city['code']==""||$city['CommitteeName']==""||$city['name']=="")
       {  
        $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Please Provide valid details!</p>");
       }else
       {
        $result = $this->CAP->cityInsertDetails($city);
                $this->session->set_flashdata("result",$result); 
       }  
       
      redirect(base_url() . 'city/addCity', 'refresh');
    }
  public function updateCityForm($id)
    {
       $data["headTitle"] = "Update City";
       $data["listType"]  = "Update City";
       $data["kshetraList"]=  $this->db->select('id,kshetra_name')
                             ->from('kshetra')->get()->result();
       $a=$this->db->select('n.*,c.name');
       $this->db->from('nagar n');
       $this->db->join('committee c', 'c.nagar_id = n.id AND n.id="'.$id.'"');
       $data["cityData"] = $a->get()->result();
       $data["id"] = $id;
       $this->load->view('backend/updateCityForm',$data);
    }
  public function cityUpdateUpd($id)
    { 
       $city['kshetras']      = $this->input->post('kshetras');
       $city['code']          = $this->input->post('code');
       $city['CommitteeName'] = $this->input->post('CommitteeName');
       $city['name']          = $this->input->post('name');
       if($city['kshetras']==""||$city['code']==""||$city['CommitteeName']==""||$city['name']=="")
       {  
         $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Please Provide valid details!</p>");
       }else
       {          
         $result = $this->CAP->cityUpdateDetails($city,$id);
          $this->session->set_flashdata("result",$result); 
       }   
          redirect(base_url() . 'city/updateCityForm/'.$id, 'refresh');
   }
  public function totalListDataCount($tablename)
    {
        $query = $this->db->select("COUNT(*) as num")->get($tablename);
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }
}


