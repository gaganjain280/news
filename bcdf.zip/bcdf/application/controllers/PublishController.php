<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class PublishController extends CI_Controller {

  function __construct(){
        parent::__construct();
        $this->load->model('Publish','publish');
        $this->load->database();
        $this->load->library('session');
  }
  
  public function index() {
        $this->load->view('backend/dashboard');
  }

  public function numRows($table_name) {
           $query = $this->db->select('*')->from($table_name)->get();
           return $query->num_rows();
  }

  public function getTableData($table_name,$limit,$offset)
  {
          $query = $this->db->select('*')
                           ->from($table_name)
                           ->limit($limit,$offset)
                           ->get();
          return $query->result();
  }

  public function newsList($value)
   {       
       $this->load->library("pagination");
       $config['base_url']= base_url().'news/list';
       $config['per_page']=2;
       $config['total_rows']=$this->numRows('news');
       $this->pagination->initialize($config);
       $data["headTitle"] = "News";
       $data["listType"]  = " News List";
       $data["newsData"]  =$this->getTableData('news',$config['per_page'],$this->uri->segment(3));
       $this->load->view('backend/newsList',$data);
   }  

    public function addNews($value='')
   {
       $data["headTitle"] = "Add News";
       $data["listType"]  = "Add News";
       $data["kshetraList"]=  $this->db->select('id,kshetra_name')
                             ->from('kshetra')->get()->result();

       $this->load->view('backend/addNewsForm',$data);
   } 
    public function updateNewsForm($value)
   {
       $condition = 'id ="'.$value.'"';
       $all_details=  $this->db->select('id,context,description,kshetra,image_name,source,status')
                ->from('news')->where($condition);
             $query = $all_details->get()->result();

       $data["kshetraList"]=  $this->db->select('id,kshetra_name')
                             ->from('kshetra')->get()->result();
       $data["headTitle"] = "Update News";
       $data["listType"] = "Update News";
       $data["updateData"] = $query;
       // print_r($data);exit;
             $this->load->view('backend/updateNewsForm',$data);
   } 

  public function newsDelete($id)
   {
       $tables = array('news');
       $this->db->where('id', $id);
       $this->db->delete($tables);
       redirect(base_url() . 'news/list/0','refresh');
   }
  public function eventDelete($id)
   {
       $tables = array('events');
       $this->db->where('id', $id);
       $this->db->delete($tables);
       redirect(base_url().'event/list/0','refresh');
   }
  public function newsInsert()
   {  
       $context           = $this->input->post('context');
       $description       = $this->input->post('description');
       $visible           = $this->input->post('visible');
       $kshetra           =json_encode($visible);
       $source            = $this->input->post('source');
       $apply             = $this->input->post('apply');
       if($apply==""){
        $apply='0';
       }else{
            $apply='1';
       }
       $config['allowed_types'] = 'gif|jpg|png|jpeg';
       $config['upload_path']   = './assets/images/news/';
       $config['encrypt_name']  = true;
       $this->load->library('upload', $config);
      if($context=="" || $description==""){  
        $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Please Provide valid details!</p>"); 
       }else{
            if($this->upload->do_upload('image'))
            {
              $image_details= $this->upload->data();
              $image_path   = $image_details['full_path'];
              $image_name   = $image_details['file_name'];
            }else{  
             $image_path=$image_name='';
            }
         $result = $this->publish->newsInsertDetails($context,$description,$kshetra,$image_path,$image_name,$source,$apply);
              $this->session->set_flashdata("result",$result); 
       
     } 
       redirect(base_url() . 'news/addNews');
}
  public function newsUpdate($id)
   {
       $context     = $this->input->post('context');
       $description = $this->input->post('description');
       $visible= $this->input->post('visible');
       $kshetra=json_encode($visible);
       $source      = $this->input->post('source');
       $apply       = $this->input->post('apply');
         // print_r($apply);exit;
       if($apply==""){
        $apply='0';
       }else{
            $apply='1';
       } 
       $config['allowed_types']   = 'gif|jpg|png|jpeg';
       $config['upload_path']     = './assets/images/news/';
       $config['encrypt_name']    = true;
       $this->load->library('upload', $config);
         if($context==""||$description=="")
       {  
      $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Please Provide valid details!</p>"); 
       }else
       {
          if($this->upload->do_upload('image'))
               {
                 $image_details= $this->upload->data();
                 $image_path   =$image_details['full_path'];
                 $image_name   =$image_details['file_name'];
               }else
               {
                 $image_path=$image_name='';
               }
         $result = $this->publish->newsUpdateDetails($id,$context,$description,$kshetra,$image_path,$image_name,$source,$apply);
               $this->session->set_flashdata("result",$result); 
            }

       redirect(base_url() . 'news/updateNewsForm/'.$id, 'refresh');
   }  

    public function addEvents($value='')
     {
        $data["headTitle"]= "Events";
        $data["listType"] = "Add Event";
        $data["kshetraList"]=  $this->db->select('id,kshetra_name')
                             ->from('kshetra')->get()->result();
          $this->load->view('backend/addEventForm',$data);
   } 

  public function eventInsert()
   {  
       $event['context']       = $this->input->post('context');
       $event['description']   = $this->input->post('description');
       $visible                = $this->input->post('visible');
       $event['kshetra']       = json_encode($visible);
       $event['sponsor']       = $this->input->post('sponsor');
       $event['organiser']     = $this->input->post('organiser');
       $apply                  = $this->input->post('apply');
        if($apply==""){
        $event['apply']='0';
       }else{
        $event['apply']='1';
       } 
       $daterange              = $this->input->post('daterange');
       $eventDate              = explode('-', $daterange);
       $event['eventStartDate']= date("Y-m-d", strtotime($eventDate[0]));
       $event['eventEndDate']  = date("Y-m-d", strtotime($eventDate[1]));
         if($event['context']==""||$event['description']==""||$event['kshetra']==""||$event['sponsor']=="")
       {  
      $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Please Provide valid details!</p>");
       }else
       {
        $this->load->library('upload');
        $image_collection = array();
        $files = $_FILES;
        $cpt = count($_FILES['userfile']['name']);
        for($i=0; $i<$cpt; $i++)
        {           
            $_FILES['userfile']['name']= $files['userfile']['name'][$i];
            $_FILES['userfile']['type']= $files['userfile']['type'][$i];
            $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
            $_FILES['userfile']['error']= $files['userfile']['error'][$i];
            $_FILES['userfile']['size']= $files['userfile']['size'][$i];   
            $config['upload_path'] = './assets/images/events/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size']      = '0';
                $config['overwrite']     = FALSE;
                $config['encrypt_name']    = true; 
            $this->upload->initialize($config);
            $this->upload->do_upload();
            $imageInfo = $this->upload->data();
            array_push($image_collection,$imageInfo['file_name']);
        }
            $event['image_name'] = json_encode(($image_collection));                
            $result = $this->publish->eventInsertDetails($event);
                $this->session->set_flashdata("result",$result); 
         }   
      $data["headTitle"] = "Add Event";
      $data["listType"]  = "Add Event";
      redirect(base_url() . 'event/addEvent', 'refresh');
   }
  
  public function eventHandleError($value="")
  {
         redirect(base_url() . 'event/list/0', 'refresh');
  }
  public function newsHandleError($value="")
  {
          redirect(base_url() . 'news/list/0', 'refresh');
  }
  public function eventList($value)
   {
        $data["headTitle"]   = "Events";
        $data["listType"]    = " Events List";
        $this->load->library("pagination");
        $config['base_url']  = base_url().'event/list';
        $config['per_page']  =2;
        $config['total_rows']=$this->numRows('events');
        $this->pagination->initialize($config);
        $data["eventData"]   =$this->getTableData('events',$config['per_page'],$this->uri->segment(3));
        $this->load->view('backend/eventList',$data);
   } 
   public function updateEventForm($value)
   {
       $condition            = 'id ="'.$value.'"';
       $all_details          =  $this->db->select(' id, context, description, sponsor, organiser, image_name, creator_id, status, kshetra, start_event_date, end_event_date')
                ->from('events')->where($condition);
       $query                = $all_details->get()->result();
       $data["kshetraList"]  =  $this->db->select('id,kshetra_name')
                             ->from('kshetra')->get()->result();
       $data["headTitle"]    = "Update Event";
       $data["listType"]     = "Update Event";
       $data["updateData"]   = $query;
       $this->load->view('backend/updateEventForm',$data);
   } 
  public function mahasabhaList($value='')
   {
        $data["headTitle"]   = "Mahasabha";
        $data["listType"]    = " Mahasabha List";
        $this->load->view('backend/mahasabhaList',$data);
   } 
  public function eventUpdate($eventId)
   {
       $is_date_update       = $this->input->post('is_date_update');
       if($is_date_update==""){
         $olddaterange       = $this->input->post('olddaterange');
         $eventDate          = explode('-', $olddaterange);
       }else{
         $newDaterange          = $this->input->post('daterange');
         $eventDate          = explode('-', $newDaterange);
       } 
       $eventStartDate       = date("Y-m-d", strtotime($eventDate[0]));
       $eventEndDate         = date("Y-m-d", strtotime($eventDate[1]));
       $context              = $this->input->post('context');
       $description          = $this->input->post('description');
       $visible              = $this->input->post('visible');
       $kshetra              = json_encode($visible);
       $sponsor              = $this->input->post('sponsor');
       $organiser            = $this->input->post('organiser');
       $apply                = $this->input->post('apply');
       $date                 = date('Y-m-d H:i:s');
       if($apply==""){
         $apply              ='0';
       }else{
         $apply              ='1';
       } 
       $image_collection     = array();
       $imageCount = count($_FILES['userfile']);
       if($_FILES['userfile']['name'][0]!==""){
          $this->load->library('upload');
          $image_collection = array();
          $files = $_FILES;
          $cpt = count($_FILES['userfile']['name']);
          for($i=0; $i<$cpt; $i++)
          {           
            $_FILES['userfile']['name']= $files['userfile']['name'][$i];
            $_FILES['userfile']['type']= $files['userfile']['type'][$i];
            $_FILES['userfile']['tmp_name']= $files['userfile']['tmp_name'][$i];
            $_FILES['userfile']['error']= $files['userfile']['error'][$i];
            $_FILES['userfile']['size']= $files['userfile']['size'][$i];   
            $config['upload_path'] = './assets/images/events/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']      = '0';
            $config['overwrite']     = FALSE;
            $config['encrypt_name']    = true; 
            $this->upload->initialize($config);
            $this->upload->do_upload();
            $imageInfo = $this->upload->data();
            array_push($image_collection,$imageInfo['file_name']);
          }     
            $this->db->set('image_name', json_encode(($image_collection)));
            $this->db->set('context', $context );
            $this->db->set('updated_at', $date);
            $this->db->set('description', $description);
            $this->db->set('kshetra', $kshetra);
            $this->db->set('start_event_date', $eventStartDate);
            $this->db->set('organiser', $organiser);
            $this->db->set('end_event_date', $eventEndDate);
            $this->db->set('status', $apply);
            $this->db->set('sponsor', $sponsor);
            $this->db->set('creator_id', 'AST-1');
            $this->db->where('id', (int)$eventId);
            $result= $this->db->update('events'); 

        }else{          
            $this->db->set('context', $context );
            $this->db->set('description', $description);
            $this->db->set('kshetra', $kshetra);
            $this->db->set('organiser', $organiser);
            $this->db->set('start_event_date', $eventStartDate);
            $this->db->set('end_event_date', $eventEndDate);
            $this->db->set('status', $apply);
            $this->db->set('sponsor', $sponsor);
            $this->db->set('creator_id', 'AST-1');
            $this->db->set('updated_at', $date);
            $this->db->where('id', (int)$eventId);
            $result= $this->db->update('events'); 
        }   
        if($result){
            $this->session->set_flashdata("result","<p class='bg-success text-white text-center'>Event Updated Successfully!</p>");     
             }else{
            $this->session->set_flashdata("result","<p class='bg-danger text-white text-center'>Event Not Updated! Something Went wromg!</p>");     
             }
       redirect(base_url() . 'event/updateEventForm/'.$eventId, 'refresh');
   } 

}
