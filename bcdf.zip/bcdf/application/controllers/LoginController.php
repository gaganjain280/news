<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*  
 *  @author   : Nitin Teli
 *  date    : 06 May 2020
 */

class LoginController extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('Authentication','auth');
        $this->load->database();
        $this->load->library('session');
	}

	
	public function index() {
		
	}

	public function login()
	{

			$username = $this->input->post('emailid');
     		$password = sha1($this->input->post('password'));
			$data = $this->auth->check_login($username, $password);
			
			if ($data == false) {
				$this->session->set_flashdata('msg','Please Check ID or Password !'); 
	            redirect(base_url() . 'login', 'refresh');
			}

			if ($data->login_status == 0) {
				$this->session->set_flashdata('msg','Your Account is not active, Please Contact Admin Authority'); 
	            redirect(base_url() . 'login', 'refresh');
			}

			if ($data->role_id == 1) {
				$this->session->set_userdata('login', 1);
				$this->session->set_userdata('role_id', $data->role_id);
		        $this->session->set_userdata('asati_id', $data->asati_id);
		        $this->session->set_userdata('email', $data->email);
		        $this->session->set_userdata('mobile', $data->mobile);
		        $this->session->set_userdata('user_id', $data->id);
		        redirect(base_url() . 'dashboard', 'refresh');
			}


	}	


	public function signup()
	{		
		try{
	    	
	    	$input = $this->input->post();
	    	$asati_id_guid = "M-".rand(); 
	        $insert_data['asati_id'] =  $asati_id_guid; 
			$insert_data['email'] = $input['email']; 
			$insert_data['mobile'] = $input['mobile']; ; 
			$insert_data['password'] =  sha1($input['password']); 
			$insert_data['login_status'] = 1; 
			$insert_data['role_id'] = 2; 
			$insert_data['created_at'] = date("Y-m-d H:i:s"); 

			if($this->db->insert('user', $insert_data)){
				
				$user_id = $this->db->insert_id();
				$famid_guid =  "F-".rand();

				$family_data['f_asati_id'] =  $famid_guid;
				$family_data['f_name'] = $input['lname'];
				$family_data['f_creator_id'] = $user_id;
				$family_data['kshetra_id'] = $input['kshetra'];
				$family_data['f_head_id'] = $user_id;

				if($this->db->insert('family', $family_data)){
					
					$family_id = $this->db->insert_id();

					$member_data['user_id'] = $user_id;
					$member_data['family_id'] = $family_id;
					$member_data['salutation'] = $input['salutation'];
					$member_data['f_name'] = $input['fname'];
					$member_data['m_name'] = $input['mname'];
					$member_data['l_name'] = $input['lname'];
					$member_data['father_name'] = $input['father'];
					$member_data['birthdate'] = $input['dob'];
					$member_data['gender'] = $input['gender'];
					
					if($this->db->insert('family_member', $member_data)){
						$this->session->set_flashdata('msg','You have Registered Successfully Your family Id is'.$famid_guid.' & Your member Id '.$asati_id_guid.' is  Please Login with your member Id.'); 
	            		redirect(base_url() . 'login', 'refresh');
					}
				}
			}
			   
	    }
	    catch( Exception $e )
	    {
	        log_message( 'error', $e->getMessage( ) . ' in ' . $e->getFile() . ':' . $e->getLine() );
	    }
		
	}


	public function logout() {
        $this->session->sess_destroy();
        $this->session->set_flashdata('logout_notification', 'logged_out');
        redirect(base_url().'index.php?login', 'refresh');
    }
}